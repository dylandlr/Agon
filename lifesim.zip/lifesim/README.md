# lifesim: emergent early societies

Phase 1 implementation of the project design: a deterministic JAX world, a
single agent learning to survive with recurrent PPO, and an event-sourced
recorder with exact rewind.

## Layout

```
lifesim/
  config.py     EnvConfig: world, ecology, body and reward parameters
  genotype.py   Heritable traits: sampling, recombination, mutation
  env.py        Pure reset/step/observe/action_mask, simultaneous resolution
  recorder.py   Event log, snapshots, action log, exact rewind
  policy.py     GRU actor-critic with action masking
  ppo.py        Phase 1 recurrent PPO: one agent per world, shared network
  ppo_multi.py  Phase 2 multi-agent PPO: one network per individual
  baselines.py  Random policy and a scripted forager (global-knowledge reference)
scripts/
  train_phase1.py   Train single-agent survival
  train_phase2.py   Train a population of individuals sharing worlds
  evaluate.py       Random vs scripted vs trained survival + record an episode
tests/
  test_env.py   Determinism, masking, contests, conservation, rewind, hunting,
                predators, violence, disease, cold, weather, trauma, huddling
```

## Quick start

```bash
pip install -e ".[dev]"          # add "jax[cuda12]" on a GPU machine
pytest -q
python scripts/train_phase1.py --timesteps 4000000 --out runs/phase1
python scripts/evaluate.py --params runs/phase1/params.msgpack
```

## What exists now

The world is 64 x 64 by default. Every mechanic is a dial in `EnvConfig`, so
experiments change configuration, never code.

**Environment.** Terrain (grass, forest, rock, water) from smooth noise.
Rock costs more to cross and can cause falls and injuries. Plants regrow by
biome, season and weather. Markov weather alternates clear and rain spells
with extreme events (drought, cold snaps, heat waves) at a rate set by
`climate_volatility`, the H3 dial. Ambient temperature follows season,
day/night and weather; forest buffers it toward comfort.

**Physiology.** Satiety, hydration, energy, health, body temperature
(relaxing toward ambient at a rate set by the insulation gene), injury,
disease, aging. Heat raises thirst through sweating; drought raises thirst
directly. Injury slows movement, can make moves fail, weakens strikes, and
bleeds when severe. Disease (from raw meat, water, or contact with sick
neighbors) raises hunger, drains energy and damages health, then leaves
immunity that wanes. Strength declines with age after 60% of lifespan.
Resting and huddling with neighbors keep agents warmer.

**Psychology.** Stress rises with damage, nearby predators and critical
needs, blocks healing when high, and costs energy. Trauma shifts the
pain-aversion phenotype away from the genotype, by an amount set by the
temperament-drift gene, then slowly recovers. Agents feel their own stress,
temperature, injury and sickness; they never observe their genes.

**Animals.** Small prey flee and can be killed by one strike. Large prey
have armor: damage below a threshold per tick does nothing, so killing one
takes several hunters striking in the same tick. Predators chase agents in
range, attack lone agents, are deterred when the target has a neighbor, and
rest after attacking. Kills drop meat, which feeds more than plants, spoils,
and can carry disease. Animal populations regrow with plant growth.

**Actions (20).** Rest, move (8), grasp, eat, drink, strike (8 directions).
Strikes hit whatever occupies the target cell, with priority predator, large
prey, small prey, agent. Striking another agent is possible and is recorded
as violence. Invalid actions are masked.

**Simultaneous resolution.** All agents act in the same tick. Contested
gathering has one strength-weighted random winner per cell; damage from
simultaneous strikes on a cell adds up, which is what makes group hunting
work. Agents are never processed in index order.

**Recorder.** Events include gathers, contests, eating, drinking, strikes,
kills by animal type, predator attacks, violence, falls, infections,
recoveries, weather changes, and deaths with cause and causal parent.
`rewind(rec, t)` replays logged actions from the nearest snapshot exactly.

**Balance (64 worlds, one agent each, one year).** Random agents are all dead
by about t=1000, mostly of thirst. The scripted forager, which sees the whole
map, keeps 61% alive to year end; winter cold is its main killer. That is
intended: winter without fire, shelter or company is the hardest test for a
solitary agent, and it is the pressure that should make grouping valuable.

## Results so far

Held-out evaluation, 128 worlds never seen in training, one agent each,
flat (MLP) encoder after 5M steps:

| Policy | Alive t=500 | t=1000 | Full year |
| --- | --- | --- | --- |
| Random | 3% | 0% | 0% |
| Scripted (sees whole map) | 95% | 84% | 52% |
| Trained (local view) | 81% | 60% | 27% |

**Finding: over-drinking.** The trained agent drinks about every 6 ticks.
Drinking when hydrated has no immediate cost, but each drink carries a small
infection risk, and illness arrives long after the drink. The agent cannot
connect them, which plausibly explains its disease deaths (24 vs 8 for the
scripted forager). This is a credit-assignment gap that a transmitted hygiene
norm could close, so it is kept as a finding rather than patched.

**Encoders.** `--encoder conv` reads the 11 x 11 view as an image with a
3-layer convolutional encoder; `--encoder mlp` flattens it. Convolutions are
implemented as patch extraction plus matmul (`PatchConv`), because XLA's
native convolution gradients ran over 100 times slower on CPU. On GPU the
native `nn.Conv` is the better choice.

## Phase 2: social world

**New primitives (33 actions total).** Release drops one unit of carried
food (meat first) on the current cell; any adjacent agent is recorded as
having seen a gift. Touch (8 directions) gives both parties a small reward
scaled by their social-reward gene. Four tokens with no built-in meaning:
emitting one costs the tick, and listeners see which token each nearby agent
emitted on the previous tick. Strikes on agents existed already.

**Appearance.** A 3-number heritable look per agent, visible to others, so
kin can resemble each other once reproduction exists (Phase 3).

**Relationship memory.** Each agent keeps a decayed record about every other
agent: struck me, gave food next to me, touched me, and seen being violent to
someone else (third-party witnessing, the raw material for reputation). It is
memory capacity, not a norm: nothing in the world reacts to it except other
agents' learned policies.

**Social observation.** In each visible cell holding another agent, the
observer sees its own memory of that agent, the agent's appearance, and the
token it emitted last tick. 22 channels over an 11 x 11 view.

**Per-agent learning (ppo_multi.py).** A population of N individuals, each
with a fixed genotype, an appearance and its own network, lives in B replica
worlds in parallel: one individual, one brain, B times the experience. Each
agent's update is clipped separately and scaled by its own learning rate
(lr0 x the lr_scale plasticity gene). `--trait-gamma` makes each agent's
discount its patience gene; it is off by default because myopic agents simply
die until evolution exists to select against them. Dead agents' steps are
masked out of learning.

**Running E0 and the scarcity dial.**

```bash
python scripts/train_phase2.py --agents 8 --worlds 16 --ticks 400000 --out runs/e0_base
python scripts/train_phase2.py --agents 8 --worlds 16 --ticks 400000 --scarcity 0.4 --out runs/e0_scarce
```

Compare `per_1000_agent_ticks.strikes_on_agents` over training. The
prediction (H1) is more violence under scarcity. Untrained agents strike each
other at random, so only the trend after learning counts.

**Speed warning.** About 1,000 agent-steps per second on one CPU core.
Meaningful Phase 2 runs need tens of millions of agent-steps: use a GPU.

## Known limits and next steps

- **Discount factor 0.997.** Threats unfold over 200 to 500 ticks; 0.99 sees
  about 100 ahead. At 2M steps 0.997 beat 0.99 (mean life 1,421 vs 1,256,
  full-year survival 31% vs 23%), but one seed each and noisy, so unconfirmed.
- **Convolutional encoder is the default.** At 820k steps it led the flat
  encoder (1,263 vs 1,163 ticks mean life) after trailing early; one seed.
- **Genotype is not observed** by the agent, matching the design: agents do
  not know their genes; genes act through the body and the reward.
- **Speed.** About 5,000 steps/sec on one CPU core with 64 environments of
  64 x 64.
  Resets are about 50 times costlier than steps, so finished environments
  draw from a pool of worlds generated once per update. Use a GPU and more
  environments for real runs.
- **Phase 1 gate:** agents reliably survive a full seasonal cycle and the
  simulation is fast enough. See the evaluation output for current status.

Next (Phase 2): multiple agents per world with the full primitive set
(release, strike, touch, cache access, tokens, pointing), relationship
memory in observations, per-agent parameters, and the E0 scarcity replication.
