"""Recurrent actor-critic. Memory lives in the GRU state; invalid actions are
masked in the logits. In later phases each agent (or lineage) owns its own
copy of these parameters, stacked and vmapped."""
from __future__ import annotations

import functools

import flax.linen as nn
import jax
import jax.numpy as jnp

MASK_VALUE = -1e9


class ScannedGRU(nn.Module):
    """GRU scanned over time. Hidden state is zeroed where `resets` is True
    (the start of a new life)."""

    @functools.partial(nn.scan, variable_broadcast="params", in_axes=0,
                       out_axes=0, split_rngs={"params": False})
    @nn.compact
    def __call__(self, carry, x):
        ins, resets = x
        carry = jnp.where(resets[:, None], jnp.zeros_like(carry), carry)
        new_carry, y = nn.GRUCell(features=carry.shape[-1])(carry, ins)
        return new_carry, y

    @staticmethod
    def initialize_carry(batch_size: int, hidden: int):
        return jnp.zeros((batch_size, hidden))


class PatchConv(nn.Module):
    """3x3 'same' convolution as im2col + Dense. Numerically a standard conv
    layer, but uses matmuls, which XLA handles far faster on CPU than conv
    gradients. stride 2 subsamples the output grid."""
    features: int
    stride: int = 1

    @nn.compact
    def __call__(self, x):                              # x: (N, H, W, C)
        h, w = x.shape[1], x.shape[2]
        xp = jnp.pad(x, ((0, 0), (1, 1), (1, 1), (0, 0)))
        patches = jnp.concatenate([xp[:, i:i + h, j:j + w, :]
                                   for i in range(3) for j in range(3)], axis=-1)
        if self.stride > 1:
            patches = patches[:, ::self.stride, ::self.stride, :]
        return nn.Dense(self.features)(patches)


class ActorCritic(nn.Module):
    """encoder="conv" reads the egocentric window as a (V, V, C) image and the
    body/time/weather features separately; encoder="mlp" flattens everything."""
    n_actions: int
    hidden: int = 128
    encoder: str = "conv"
    view_size: int = 11
    channels: int = 11

    @nn.compact
    def __call__(self, carry, x):
        """x = (obs [T, B, D], resets [T, B], mask [T, B, A])."""
        obs, resets, mask = x
        if self.encoder == "conv":
            t, b, _ = obs.shape
            n_win = self.view_size ** 2 * self.channels
            win = obs[..., :n_win].reshape(t * b, self.view_size, self.view_size, self.channels)
            feats = obs[..., n_win:]
            z = nn.relu(PatchConv(16)(win))
            z = nn.relu(PatchConv(32, stride=2)(z))
            z = nn.relu(PatchConv(32, stride=2)(z))
            z = z.reshape(t, b, -1)
            h = jnp.concatenate([nn.relu(nn.Dense(self.hidden)(z)),
                                 nn.relu(nn.Dense(64)(feats))], axis=-1)
        else:
            h = nn.relu(nn.Dense(self.hidden)(obs))
        h = nn.relu(nn.Dense(self.hidden)(h))
        carry, h = ScannedGRU()(carry, (h, resets))
        logits = nn.Dense(self.n_actions, kernel_init=nn.initializers.orthogonal(0.01))(
            nn.relu(nn.Dense(self.hidden)(h)))
        logits = jnp.where(mask, logits, MASK_VALUE)
        value = nn.Dense(1, kernel_init=nn.initializers.orthogonal(1.0))(
            nn.relu(nn.Dense(self.hidden)(h)))
        return carry, logits, value.squeeze(-1)


def make_network(env_cfg, hidden: int = 128, encoder: str = "conv") -> ActorCritic:
    from . import env as E
    return ActorCritic(n_actions=E.N_ACTIONS, hidden=hidden, encoder=encoder,
                       view_size=env_cfg.view_size, channels=E.N_OBS_CHANNELS)
