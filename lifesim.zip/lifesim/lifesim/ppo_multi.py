"""Phase 2 trainer: multi-agent recurrent PPO with one network per individual.

Setup: a population of N individuals, each with a fixed genotype, appearance
and its own policy parameters (stacked along a leading axis of size N). The
same N individuals live in B replica worlds in parallel, so each individual
gathers B times more experience per tick while staying one individual with
one brain and one set of genes.

Per-agent learning: gradients are clipped per agent, Adam runs element-wise,
and each agent's update is scaled by its own learning rate,
lr_i = lr0 * lr_scale_i (the plasticity gene). Optionally the discount factor
comes from the patience gene.

Dead agents stay dead until their world resets; their steps are masked out of
the loss. An agent's death is terminal for its own returns.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import NamedTuple

import jax
import jax.numpy as jnp
import optax

from . import env as E
from . import genotype as gt
from .config import EnvConfig
from .policy import make_network


@dataclass(frozen=True)
class MAConfig:
    num_worlds: int = 16
    num_steps: int = 128
    total_ticks: int = 200_000      # world-ticks per replica (x num_worlds for env steps)
    lr: float = 3e-4
    gamma: float = 0.997
    trait_gamma: bool = False       # use each agent's patience gene as its discount
    per_agent_lr: bool = True       # scale updates by the lr_scale gene
    gae_lambda: float = 0.95
    clip_eps: float = 0.2
    ent_coef: float = 0.005
    vf_coef: float = 0.5
    max_grad_norm: float = 0.5
    update_epochs: int = 4
    num_minibatches: int = 4        # split over worlds
    hidden: int = 128
    encoder: str = "conv"
    seed: int = 0

    @property
    def num_updates(self) -> int:
        return self.total_ticks // self.num_steps


class Transition(NamedTuple):   # all fields (N, B, ...)
    reset: jnp.ndarray
    done: jnp.ndarray
    valid: jnp.ndarray
    action: jnp.ndarray
    value: jnp.ndarray
    reward: jnp.ndarray
    log_prob: jnp.ndarray
    obs: jnp.ndarray
    mask: jnp.ndarray


class Population(NamedTuple):
    genotype: gt.Genotype       # (N,) per trait
    appearance: jnp.ndarray     # (N, 3)


def _per_agent_clip(grads, max_norm):
    sq = sum(jnp.sum(g.reshape(g.shape[0], -1) ** 2, axis=1)
             for g in jax.tree_util.tree_leaves(grads))
    scale = jnp.minimum(1.0, max_norm / (jnp.sqrt(sq) + 1e-8))
    return jax.tree_util.tree_map(lambda g: g * scale.reshape((-1,) + (1,) * (g.ndim - 1)), grads)


def _scale_per_agent(updates, lrs):
    return jax.tree_util.tree_map(lambda u: u * lrs.reshape((-1,) + (1,) * (u.ndim - 1)), updates)


def _swap_axes_nb(x):
    """(B, N, ...) <-> (N, B, ...)"""
    return jnp.swapaxes(x, 0, 1)


def make_train(env_cfg: EnvConfig, cfg: MAConfig):
    n, b = env_cfg.n_agents, cfg.num_worlds
    net = make_network(env_cfg, cfg.hidden, cfg.encoder)
    adam = optax.adam(1.0, eps=1e-5)          # direction only; per-agent lr applied after

    def apply_agent(p, carry, obs, reset, mask):
        """One agent's network over its B worlds. obs (T, B, D)."""
        return net.apply(p, carry, (obs, reset, mask))

    v_apply = jax.vmap(apply_agent)            # over agents: params, carry (N,B,H), x (N,T,B,..)

    def reset_worlds(key, pop: Population):
        return jax.vmap(lambda k: E.reset(k, env_cfg, pop.genotype, pop.appearance))(
            jax.random.split(key, b))

    def observe(states):
        obs = jax.vmap(lambda s: E.observe(s, env_cfg))(states)         # (B, N, D)
        mask = jax.vmap(lambda s: E.action_mask(s, env_cfg))(states)    # (B, N, A)
        return _swap_axes_nb(obs), _swap_axes_nb(mask)

    def init(key):
        k_pop, k_app, k_net, k_env, k_run = jax.random.split(key, 5)
        pop = Population(gt.sample(k_pop, n), jax.random.uniform(k_app, (n, E.N_APPEARANCE)))
        states = reset_worlds(k_env, pop)
        obs, mask = observe(states)
        carry = jnp.zeros((n, b, cfg.hidden))
        dummy = (jnp.zeros((1, b, obs.shape[-1])), jnp.zeros((1, b), bool),
                 jnp.ones((1, b, E.N_ACTIONS), bool))
        params = jax.vmap(lambda k: net.init(k, jnp.zeros((b, cfg.hidden)), dummy))(
            jax.random.split(k_net, n))
        opt_state = adam.init(params)
        reset_flag = jnp.ones((n, b), bool)
        return (params, opt_state, states, obs, mask, reset_flag, carry, k_run), pop

    def lrs_of(pop: Population):
        scale = pop.genotype.lr_scale if cfg.per_agent_lr else jnp.ones(n)
        return cfg.lr * scale

    def gammas_of(pop: Population):
        g = pop.genotype.patience if cfg.trait_gamma else jnp.full(n, cfg.gamma)
        return g[:, None]                                               # (N, 1)

    def update(runner, pop: Population):
        params, opt_state, states, obs, mask, reset_flag, carry, key = runner
        init_carry = carry
        key, k_pool = jax.random.split(key)
        pool = reset_worlds(k_pool, pop)

        # ---------------------------------------------------- rollout
        def env_step(c, _):
            params, states, obs, mask, reset_flag, carry, key = c
            key, k_act, k_pick = jax.random.split(key, 3)
            carry, logits, value = v_apply(params, carry, obs[:, None], reset_flag[:, None],
                                           mask[:, None])
            logits, value = logits[:, 0], value[:, 0]                   # (N, B, A), (N, B)
            action = jax.random.categorical(k_act, logits)
            log_prob = jnp.take_along_axis(jax.nn.log_softmax(logits), action[..., None], -1)[..., 0]
            alive_before = _swap_axes_nb(states.alive)                  # (N, B)
            ages_before = _swap_axes_nb(states.age)
            nxt, reward, done, info = jax.vmap(lambda s, a: E.step(s, a, env_cfg))(
                states, _swap_axes_nb(action))
            idx = jax.random.randint(k_pick, (b,), 0, b)
            fresh = jax.tree_util.tree_map(lambda x: x[idx], pool)
            fresh = fresh._replace(key=jax.vmap(lambda k: jax.random.fold_in(k, 1))(fresh.key))
            sel = lambda f, s: jnp.where(done.reshape((-1,) + (1,) * (s.ndim - 1)), f, s)
            states2 = jax.tree_util.tree_map(sel, fresh, nxt)
            obs2, mask2 = observe(states2)
            died = _swap_axes_nb(info.died)
            agent_done = died | done[None, :]
            tr = Transition(reset_flag, agent_done, alive_before, action, value,
                            _swap_axes_nb(reward), log_prob, obs, mask)
            stats = {
                "alive": alive_before.sum(),
                "deaths": died.sum(),
                "age_at_death": jnp.where(died, ages_before + 1, 0).sum(),
                "cause": jnp.stack([(died & (_swap_axes_nb(info.death_cause) == c)).sum()
                                    for c in range(len(E.CAUSE_NAMES))]),
                "hits": info.hits.sum(),
                "gifts": jnp.any(info.gifts, axis=-1).sum(),
                "touches": jnp.any(info.touches, axis=-1).sum(),
                "tokens": (info.token >= 0).sum(),
                "kills": info.kills.sum(axis=(0, 1)),
                "world_ends": done.sum(),
            }
            new_reset = jnp.broadcast_to(done[None, :], (n, b))
            return (params, states2, obs2, mask2, new_reset, carry, key), (tr, stats)

        c0 = (params, states, obs, mask, reset_flag, carry, key)
        (params, states, obs, mask, reset_flag, carry, key), (traj, stats) = jax.lax.scan(
            env_step, c0, None, cfg.num_steps)

        # ---------------------------------------------------- GAE (per agent)
        _, _, last_val = v_apply(params, carry, obs[:, None], reset_flag[:, None], mask[:, None])
        last_val = last_val[:, 0]
        gam = gammas_of(pop)

        def gae_step(c, tr):
            gae, next_val = c
            delta = tr.reward + gam * next_val * (1 - tr.done) - tr.value
            gae = delta + gam * cfg.gae_lambda * (1 - tr.done) * gae
            return (gae, tr.value), gae

        _, adv = jax.lax.scan(gae_step, (jnp.zeros_like(last_val), last_val), traj, reverse=True)
        targets = adv + traj.value

        # ---------------------------------------------------- loss (one agent)
        def agent_loss(p, ic, tr, adv, tg):
            """tr fields (T, B, ...) for one agent."""
            _, logits, value = net.apply(p, ic, (tr.obs, tr.reset, tr.mask))
            w = tr.valid.astype(jnp.float32)
            denom = jnp.maximum(w.sum(), 1.0)
            logp_all = jax.nn.log_softmax(logits)
            logp = jnp.take_along_axis(logp_all, tr.action[..., None], -1)[..., 0]
            ratio = jnp.exp(logp - tr.log_prob)
            mean = (adv * w).sum() / denom
            std = jnp.sqrt((((adv - mean) ** 2) * w).sum() / denom) + 1e-8
            an = (adv - mean) / std
            pg = -jnp.minimum(ratio * an, jnp.clip(ratio, 1 - cfg.clip_eps, 1 + cfg.clip_eps) * an)
            v_clip = tr.value + jnp.clip(value - tr.value, -cfg.clip_eps, cfg.clip_eps)
            vf = 0.5 * jnp.maximum((value - tg) ** 2, (v_clip - tg) ** 2)
            ent = -(jnp.exp(logp_all) * jnp.where(tr.mask, logp_all, 0.0)).sum(-1)
            per_step = pg + cfg.vf_coef * vf - cfg.ent_coef * ent
            return (per_step * w).sum() / denom, ((ent * w).sum() / denom)

        def total_loss(params, ic, tr, adv, tg):
            # Agent axis is 0 for params/ic, 1 for (T, N, B, ...) data
            losses, ents = jax.vmap(agent_loss, in_axes=(0, 0, 1, 1, 1))(params, ic, tr, adv, tg)
            return losses.sum(), ents.mean()

        lrs = lrs_of(pop)

        def epoch(c, _):
            params, opt_state, key = c
            key, k = jax.random.split(key)
            perm = jax.random.permutation(k, b)
            mb = b // cfg.num_minibatches

            def split(x, world_axis):
                x = jnp.take(x, perm, axis=world_axis)
                shape = x.shape[:world_axis] + (cfg.num_minibatches, mb) + x.shape[world_axis + 1:]
                return jnp.moveaxis(x.reshape(shape), world_axis, 0)

            batches = (jax.tree_util.tree_map(lambda x: split(x, 2), traj),
                       split(adv, 2), split(targets, 2), split(init_carry, 1))

            def mb_step(c, bt):
                params, opt_state = c
                tr, a, tg, ic = bt
                grads, ent = jax.grad(total_loss, has_aux=True)(params, ic, tr, a, tg)
                grads = _per_agent_clip(grads, cfg.max_grad_norm)
                updates, opt_state = adam.update(grads, opt_state, params)
                params = optax.apply_updates(params, _scale_per_agent(updates, lrs))
                return (params, opt_state), ent

            (params, opt_state), ents = jax.lax.scan(mb_step, (params, opt_state), batches)
            return (params, opt_state, key), ents

        (params, opt_state, key), ents = jax.lax.scan(epoch, (params, opt_state, key), None,
                                                      cfg.update_epochs)
        runner = (params, opt_state, states, obs, mask, reset_flag, carry, key)
        metrics = jax.tree_util.tree_map(lambda x: x.sum(0), stats)
        metrics["entropy"] = ents.mean()
        return runner, metrics

    return net, init, jax.jit(update)
