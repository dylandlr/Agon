"""Static configuration for the world. All fields are hashable so the config
can be passed as a static argument to jitted functions. Every mechanic is a
dial here, so experiments change config, never code."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EnvConfig:
    # ------------------------------------------------------------ world
    grid_size: int = 64
    n_agents: int = 1
    max_steps: int = 2000          # episode time limit (ticks)
    day_length: int = 50           # ticks per day
    season_length: int = 500       # ticks per season (4 seasons = 1 year)

    # Terrain generation (fractions are approximate)
    water_fraction: float = 0.08
    rock_fraction: float = 0.10
    forest_fraction: float = 0.30  # remainder is grassland
    rock_fall_prob: float = 0.01   # chance of a fall injury when moving onto rock
    rock_fall_injury: float = 0.1

    # ------------------------------------------------------------ plants
    plant_max: float = 3.0
    plant_regrow_forest: float = 0.020
    plant_regrow_grass: float = 0.008
    winter_regrow_factor: float = 0.1
    gather_amount: float = 1.0

    # ------------------------------------------------------------ weather
    # Markov weather: clear, rain, drought, cold snap, heat wave.
    climate_volatility: float = 0.3   # chance a new weather spell is an extreme event
    spell_min: int = 60
    spell_max: int = 300
    rain_regrow_mult: float = 1.5
    drought_regrow_mult: float = 0.3
    drought_thirst_mult: float = 1.5
    extreme_temp_shift: float = 10.0  # degrees for cold snaps and heat waves

    # ------------------------------------------------------------ temperature
    season_temp: tuple = (12.0, 25.0, 12.0, 2.0)   # spring, summer, autumn, winter (C)
    day_temp_swing: float = 6.0
    forest_buffer: float = 0.5      # forest pulls ambient 50% toward comfort
    comfort_temp: float = 18.0
    temp_scale: float = 20.0        # degrees away from comfort for full thermal load
    thermal_rate: float = 0.03      # body temp relaxation rate (divided by insulation)
    rest_warmth: float = 0.15       # resting (huddled) shifts thermal load warmer
    huddle_warmth: float = 0.05     # per adjacent living agent, up to 3
    cold_threshold: float = -0.7    # body-temp state below this causes damage
    heat_threshold: float = 0.5
    cold_damage: float = 0.006
    heat_damage: float = 0.004
    sweat_thirst_mult: float = 1.0  # extra thirst per unit body temp above 0.2

    # ------------------------------------------------------------ body
    hunger_rate: float = 0.004
    thirst_rate: float = 0.006
    fatigue_rate: float = 0.002
    move_cost: float = 0.002
    rest_recovery: float = 0.02
    night_rest_bonus: float = 1.5
    plant_food_value: float = 0.35
    meat_food_value: float = 0.8    # meat is denser food
    drink_value: float = 0.5
    starve_damage: float = 0.01
    thirst_damage: float = 0.015
    exhaust_damage: float = 0.005
    heal_rate: float = 0.002
    inventory_cap: float = 5.0
    max_age: int = 20000
    senescence_start: float = 0.6   # fraction of lifespan when strength starts to decline

    # Injury
    injury_heal_rate: float = 0.001
    injury_move_fail: float = 0.5   # move fails with prob injury * this
    injury_bleed: float = 0.003     # health loss per tick at full injury above 0.5

    # Disease (SIR-style per agent)
    disease_duration: int = 200
    disease_damage: float = 0.004
    disease_hunger_mult: float = 0.5
    disease_fatigue: float = 0.002
    raw_meat_infection: float = 0.03
    water_infection: float = 0.002  # per drink, doubled in drought
    contact_infection: float = 0.02 # per tick per infected neighbor (multi-agent)
    immunity_decay: float = 0.0005

    # Stress (psychological state, felt by the agent)
    stress_from_damage: float = 3.0  # per unit health lost
    stress_from_threat: float = 0.03 # per tick with a predator within 3 cells
    stress_from_need: float = 0.005  # per critical need per tick
    stress_decay: float = 0.99
    stress_energy_cost: float = 0.002
    stress_heal_block: float = 0.7   # no healing above this stress
    trauma_rate: float = 2.0         # pain-aversion phenotype gain per health lost
    trauma_recovery: float = 0.0005  # drift back toward genotype per tick

    # ------------------------------------------------------------ animals
    # Densities are per 1000 cells; counts are fixed array capacities.
    small_prey_per_1000: float = 12.0
    large_prey_per_1000: float = 3.0
    predators_per_1000: float = 1.0
    small_prey_hp: float = 0.5
    large_prey_hp: float = 3.0
    large_prey_armor: float = 0.8    # per-tick damage below this does nothing: needs a group
    predator_hp: float = 1.5
    predator_armor: float = 0.3
    small_prey_meat: float = 1.0
    large_prey_meat: float = 6.0
    strike_damage: float = 0.6       # scaled by strength, age and injury
    small_prey_notice: int = 2
    large_prey_notice: int = 3
    predator_notice: int = 5
    small_prey_flee_prob: float = 0.7
    large_prey_flee_prob: float = 0.6
    predator_chase_prob: float = 0.85
    wander_prob: float = 0.3
    predator_attack_prob: float = 0.3
    predator_attack_damage: float = 0.12
    predator_attack_injury: float = 0.15
    predator_rest_ticks: int = 150   # after an attack the predator stops hunting
    predator_prey_kill_prob: float = 0.2
    animal_hp_regen: float = 0.02
    small_prey_respawn: float = 0.002
    large_prey_respawn: float = 0.0005
    predator_respawn: float = 0.0005
    meat_spoil_ground: float = 0.01
    meat_spoil_inventory: float = 0.002

    # ------------------------------------------------------------ social
    memory_decay: float = 0.999      # relationship memory half-life ~700 ticks
    touch_reward: float = 0.005      # scaled by the social_reward gene, for both parties

    # ------------------------------------------------------------ observation
    view_radius: int = 5

    # ------------------------------------------------------------ reward
    alive_reward: float = 0.01
    death_penalty: float = 1.0
    novelty_reward: float = 0.002

    @property
    def view_size(self) -> int:
        return 2 * self.view_radius + 1

    @property
    def year_length(self) -> int:
        return 4 * self.season_length

    def _count(self, per_1000: float) -> int:
        return max(1, int(round(per_1000 * self.grid_size ** 2 / 1000)))

    @property
    def n_small_prey(self) -> int:
        return self._count(self.small_prey_per_1000)

    @property
    def n_large_prey(self) -> int:
        return self._count(self.large_prey_per_1000)

    @property
    def n_predators(self) -> int:
        return self._count(self.predators_per_1000)
