"""Core world simulation. Pure, jittable, deterministic given the PRNG key.

Mechanics: terrain with rock falls, seasonal plants, Markov weather (rain,
drought, cold snaps, heat waves), ambient temperature and body temperature,
hunger/thirst/fatigue, injury, disease with immunity, stress and trauma-driven
temperament drift, aging, small prey, large prey that need group hunting,
predators deterred by groups, meat that spoils.

All agents act in the same tick; conflicts resolve with seeded randomness.
Nothing here scripts social behavior: strikes hit whatever is in the target
cell, including other agents.
"""
from __future__ import annotations

from typing import NamedTuple

import jax
import jax.numpy as jnp

from . import genotype as gt
from .config import EnvConfig

# ---------------------------------------------------------------- terrain
GRASS, FOREST, ROCK, WATER = 0, 1, 2, 3
N_TERRAIN = 4
TERRAIN_MOVE_COST = jnp.array([1.0, 1.3, 2.0, 0.0])

# ---------------------------------------------------------------- weather
CLEAR, RAIN, DROUGHT, COLD_SNAP, HEAT_WAVE = range(5)
N_WEATHER = 5
WEATHER_NAMES = ["clear", "rain", "drought", "cold_snap", "heat_wave"]

# ---------------------------------------------------------------- actions
REST = 0
MOVE_N, MOVE_NE, MOVE_E, MOVE_SE, MOVE_S, MOVE_SW, MOVE_W, MOVE_NW = range(1, 9)
GRASP, EAT, DRINK = 9, 10, 11
STRIKE_N = 12                     # STRIKE_N .. STRIKE_NW = 12 .. 19
RELEASE = 20                      # drop one unit of carried food on the current cell
TOUCH_N = 21                      # TOUCH_N .. TOUCH_NW = 21 .. 28
TOKEN_0 = 29                      # emit token k = TOKEN_0 + k; tokens have no built-in meaning
N_TOKENS = 4
N_ACTIONS = TOKEN_0 + N_TOKENS
_DIRS = ["n", "ne", "e", "se", "s", "sw", "w", "nw"]
ACTION_NAMES = (["rest"] + [f"move_{d}" for d in _DIRS] + ["grasp", "eat", "drink"]
                + [f"strike_{d}" for d in _DIRS] + ["release"]
                + [f"touch_{d}" for d in _DIRS] + [f"token_{k}" for k in range(N_TOKENS)])

MOVE_DELTAS = jnp.array([[0, 0], [-1, 0], [-1, 1], [0, 1], [1, 1],
                         [1, 0], [1, -1], [0, -1], [-1, -1]], dtype=jnp.int32)
NEIGHBORS8 = MOVE_DELTAS[1:]

# ---------------------------------------------------------------- outcomes
(OUT_NONE, OUT_REST, OUT_MOVE, OUT_GATHER, OUT_GATHER_LOST, OUT_EAT, OUT_DRINK,
 OUT_STRIKE_MISS, OUT_STRIKE_ANIMAL, OUT_STRIKE_AGENT, OUT_KILL, OUT_MOVE_FAILED,
 OUT_RELEASE, OUT_TOUCH, OUT_TOKEN) = range(15)
OUTCOME_NAMES = ["none", "rest", "move", "gather", "gather_lost", "eat", "drink",
                 "strike_miss", "strike_animal", "strike_agent", "kill", "move_failed",
                 "release", "touch", "token"]

# Death causes: index 1.. match the damage component order in step()
CAUSE_NAMES = ["none", "starvation", "thirst", "exhaustion", "cold", "heat",
               "disease", "predation", "violence", "injury", "age"]
(CAUSE_NONE, CAUSE_STARVATION, CAUSE_THIRST, CAUSE_EXHAUSTION, CAUSE_COLD, CAUSE_HEAT,
 CAUSE_DISEASE, CAUSE_PREDATION, CAUSE_VIOLENCE, CAUSE_INJURY, CAUSE_AGE) = range(11)

ANIMAL_SMALL, ANIMAL_LARGE, ANIMAL_PREDATOR = 0, 1, 2

SEASON_REGROW = (1.0, 0.8, 0.5)

# Relationship memory: what observer i has seen agent j do (decayed counts)
MEM_STRUCK_ME, MEM_GAVE_NEAR_ME, MEM_TOUCHED_ME, MEM_SEEN_VIOLENT = range(4)
N_MEM = 4
MEM_NAMES = ["struck_me", "gave_near_me", "touched_me", "seen_violent"]
N_APPEARANCE = 3
# Per visible agent: memory about it, its appearance, the token it emitted last tick
N_SOCIAL_FEATURES = N_MEM + N_APPEARANCE + N_TOKENS

# Observation: terrain one-hot, plants, meat, agents, small prey, large prey,
# predators, out-of-bounds, then social features of agents in each cell
N_OBS_CHANNELS = N_TERRAIN + 7 + N_SOCIAL_FEATURES
N_BODY_FEATURES = 13 + 5 + N_WEATHER


# ---------------------------------------------------------------- state
class Animals(NamedTuple):
    pos: jnp.ndarray      # (M, 2) int32
    alive: jnp.ndarray    # (M,) bool
    hp: jnp.ndarray       # (M,) float32
    rest: jnp.ndarray     # (M,) int32 ticks of not hunting (predators only)


class State(NamedTuple):
    key: jax.Array
    t: jnp.ndarray
    terrain: jnp.ndarray        # (G, G) int32
    plants: jnp.ndarray         # (G, G)
    meat: jnp.ndarray           # (G, G) meat lying on the ground
    weather: jnp.ndarray        # scalar int32
    weather_timer: jnp.ndarray  # scalar int32
    # agents
    pos: jnp.ndarray            # (N, 2) int32
    satiety: jnp.ndarray
    hydration: jnp.ndarray
    energy: jnp.ndarray
    health: jnp.ndarray
    plant_inv: jnp.ndarray
    meat_inv: jnp.ndarray
    age: jnp.ndarray            # (N,) int32
    alive: jnp.ndarray          # (N,) bool
    visited: jnp.ndarray        # (N, G, G) bool
    body_temp: jnp.ndarray      # (N,) thermal state, 0 = comfortable
    injury: jnp.ndarray         # (N,) in [0, 1]
    infection: jnp.ndarray      # (N,) int32 ticks of illness remaining
    immunity: jnp.ndarray       # (N,) in [0, 1]
    stress: jnp.ndarray         # (N,) in [0, 1]
    pain_aversion: jnp.ndarray  # (N,) phenotype; drifts from genotype with trauma
    genotype: gt.Genotype
    appearance: jnp.ndarray     # (N, 3) heritable look; lets kin resemble each other
    memory: jnp.ndarray         # (N, N, N_MEM) observer i's decayed record of agent j
    last_token: jnp.ndarray     # (N,) int32 token emitted last tick, -1 if none
    # animals
    small: Animals
    large: Animals
    predators: Animals


class StepInfo(NamedTuple):
    outcome: jnp.ndarray        # (N,) outcome code
    died: jnp.ndarray
    death_cause: jnp.ndarray
    gathered: jnp.ndarray
    health_loss: jnp.ndarray
    pos: jnp.ndarray
    t: jnp.ndarray
    attacked_by_predator: jnp.ndarray  # (N,) bool
    struck_by_agent: jnp.ndarray       # (N,) bool
    newly_infected: jnp.ndarray        # (N,) bool
    recovered: jnp.ndarray             # (N,) bool
    fell: jnp.ndarray                  # (N,) bool, rock fall
    kills: jnp.ndarray                 # (N, 3) animals killed this tick by type
    weather: jnp.ndarray               # scalar
    weather_changed: jnp.ndarray       # scalar bool
    ambient_temp: jnp.ndarray          # (N,) degrees at each agent
    hits: jnp.ndarray                  # (N, N) bool: i struck j this tick
    gifts: jnp.ndarray                 # (N, N) bool: i released food next to j
    touches: jnp.ndarray               # (N, N) bool: i touched j
    token: jnp.ndarray                 # (N,) int32 token emitted, -1 if none


# ---------------------------------------------------------------- helpers
def season_of(t, cfg: EnvConfig):
    return (t // cfg.season_length) % 4


def is_night(t, cfg: EnvConfig):
    return (t % cfg.day_length) >= (cfg.day_length // 2)


def _smooth_noise(key, size, coarse):
    small = jax.random.normal(key, (coarse, coarse))
    return jax.image.resize(small, (size, size), method="linear")


def generate_terrain(key, cfg: EnvConfig):
    k_elev, k_moist = jax.random.split(key)
    coarse = max(4, cfg.grid_size // 6)
    elev = _smooth_noise(k_elev, cfg.grid_size, coarse)
    moist = _smooth_noise(k_moist, cfg.grid_size, coarse)
    water_thr = jnp.quantile(elev, cfg.water_fraction)
    rock_thr = jnp.quantile(elev, 1.0 - cfg.rock_fraction)
    forest_thr = jnp.quantile(moist, 1.0 - cfg.forest_fraction)
    terrain = jnp.full(elev.shape, GRASS, dtype=jnp.int32)
    terrain = jnp.where(moist >= forest_thr, FOREST, terrain)
    terrain = jnp.where(elev >= rock_thr, ROCK, terrain)
    return jnp.where(elev <= water_thr, WATER, terrain)


def _in_bounds(p, g):
    return jnp.all((p >= 0) & (p < g), axis=-1)


def _cheb(a, b):
    return jnp.max(jnp.abs(a - b), axis=-1)


def adjacent_to_water(terrain, pos, cfg: EnvConfig):
    g = cfg.grid_size
    nb = pos[:, None, :] + NEIGHBORS8[None]
    ok = _in_bounds(nb, g)
    nbc = jnp.clip(nb, 0, g - 1)
    return jnp.any(ok & (terrain[nbc[..., 0], nbc[..., 1]] == WATER), axis=1)


def _random_land_cells(key, terrain, n):
    g = terrain.shape[0]
    walkable = (terrain != WATER).reshape(-1).astype(jnp.float32)
    cells = jax.random.choice(key, g * g, (n,), replace=True, p=walkable / walkable.sum())
    return jnp.stack([cells // g, cells % g], axis=-1).astype(jnp.int32)


def _occupancy(pos, alive, g):
    return jnp.zeros((g, g)).at[pos[:, 0], pos[:, 1]].add(alive.astype(jnp.float32))


def _new_animals(key, terrain, n, hp):
    return Animals(pos=_random_land_cells(key, terrain, n), alive=jnp.ones(n, bool),
                   hp=jnp.full(n, hp), rest=jnp.zeros(n, jnp.int32))


def ambient_temperature(t, weather, terrain_at, cfg: EnvConfig):
    """Degrees C at given cells. Seasons, day/night, weather, forest buffering."""
    season = season_of(t, cfg)
    base = jnp.array(cfg.season_temp)[season]
    day_phase = 2 * jnp.pi * (t % cfg.day_length) / cfg.day_length
    temp = base - cfg.day_temp_swing * jnp.cos(day_phase)   # coldest at phase 0
    temp = temp + jnp.where(weather == COLD_SNAP, -cfg.extreme_temp_shift, 0.0)
    temp = temp + jnp.where(weather == HEAT_WAVE, cfg.extreme_temp_shift, 0.0)
    buffered = temp + cfg.forest_buffer * (cfg.comfort_temp - temp)
    return jnp.where(terrain_at == FOREST, buffered, temp)


# ---------------------------------------------------------------- reset
def reset(key: jax.Array, cfg: EnvConfig, genotype: gt.Genotype | None = None,
          appearance: jnp.ndarray | None = None) -> State:
    """New world. Pass `genotype`/`appearance` to keep a fixed population
    (the same individuals) across many replica worlds."""
    ks = jax.random.split(key, 10)
    g, n = cfg.grid_size, cfg.n_agents
    terrain = generate_terrain(ks[0], cfg)
    base = jnp.where(terrain == FOREST, 0.7, jnp.where(terrain == GRASS, 0.4, 0.0))
    plants = base * cfg.plant_max * jax.random.uniform(ks[1], (g, g))
    pos = _random_land_cells(ks[2], terrain, n)
    body = jax.random.uniform(ks[3], (3, n), minval=0.8, maxval=1.0)
    geno = gt.sample(ks[4], n) if genotype is None else genotype
    if appearance is None:
        appearance = jax.random.uniform(ks[9], (n, N_APPEARANCE))
    visited = jnp.zeros((n, g, g), bool).at[jnp.arange(n), pos[:, 0], pos[:, 1]].set(True)
    return State(
        key=ks[8], t=jnp.int32(0), terrain=terrain, plants=plants,
        meat=jnp.zeros((g, g)), weather=jnp.int32(CLEAR),
        weather_timer=jnp.int32(cfg.spell_min),
        pos=pos, satiety=body[0], hydration=body[1], energy=body[2], health=jnp.ones(n),
        plant_inv=jnp.zeros(n), meat_inv=jnp.zeros(n), age=jnp.zeros(n, jnp.int32),
        alive=jnp.ones(n, bool), visited=visited, body_temp=jnp.zeros(n),
        injury=jnp.zeros(n), infection=jnp.zeros(n, jnp.int32), immunity=jnp.zeros(n),
        stress=jnp.zeros(n), pain_aversion=geno.pain_aversion, genotype=geno,
        appearance=appearance, memory=jnp.zeros((n, n, N_MEM)),
        last_token=jnp.full((n,), -1, jnp.int32),
        small=_new_animals(ks[5], terrain, cfg.n_small_prey, cfg.small_prey_hp),
        large=_new_animals(ks[6], terrain, cfg.n_large_prey, cfg.large_prey_hp),
        predators=_new_animals(ks[7], terrain, cfg.n_predators, cfg.predator_hp),
    )


# ---------------------------------------------------------------- masks
def action_mask(state: State, cfg: EnvConfig) -> jnp.ndarray:
    g = cfg.grid_size
    tgt = state.pos[:, None, :] + NEIGHBORS8[None]
    ok = _in_bounds(tgt, g)
    tc = jnp.clip(tgt, 0, g - 1)
    can_move = ok & (state.terrain[tc[..., 0], tc[..., 1]] != WATER)
    r, c = state.pos[:, 0], state.pos[:, 1]
    carried = state.plant_inv + state.meat_inv
    has_food_here = (state.plants[r, c] > 0.1) | (state.meat[r, c] > 0.1)
    can_grasp = has_food_here & (carried < cfg.inventory_cap - 1e-3)
    can_eat = carried > 0.05
    can_drink = adjacent_to_water(state.terrain, state.pos, cfg)
    can_strike = ok                                      # striking empty air is allowed
    can_release = carried > 0.05
    can_token = jnp.ones((state.pos.shape[0], N_TOKENS), bool)
    mask = jnp.concatenate([jnp.ones_like(can_eat)[:, None], can_move, can_grasp[:, None],
                            can_eat[:, None], can_drink[:, None], can_strike,
                            can_release[:, None], ok, can_token], axis=1)
    dead = jnp.zeros_like(mask).at[:, REST].set(True)
    return jnp.where(state.alive[:, None], mask, dead)


# ---------------------------------------------------------------- observation
def observe(state: State, cfg: EnvConfig) -> jnp.ndarray:
    """(N, obs_dim): egocentric window (gathered, not padded) + body/time/weather."""
    g, r, n, v = cfg.grid_size, cfg.view_radius, cfg.n_agents, cfg.view_size
    offs = jnp.arange(-r, r + 1)
    rows = state.pos[:, 0, None, None] + offs[None, :, None]          # (N, V, 1)
    cols = state.pos[:, 1, None, None] + offs[None, None, :]          # (N, 1, V)
    rows, cols = jnp.broadcast_arrays(rows, cols)                     # (N, V, V)
    inb = (rows >= 0) & (rows < g) & (cols >= 0) & (cols < g)
    rc, cc = jnp.clip(rows, 0, g - 1), jnp.clip(cols, 0, g - 1)

    def take(grid):
        return jnp.where(inb, grid[rc, cc], 0.0)

    agents_grid = _occupancy(state.pos, state.alive, g)
    chans = [jnp.where(inb[..., None], jax.nn.one_hot(state.terrain[rc, cc], N_TERRAIN), 0.0),
             take(state.plants / cfg.plant_max)[..., None],
             take(jnp.minimum(state.meat / cfg.large_prey_meat, 1.0))[..., None],
             take(agents_grid)[..., None],
             take(_occupancy(state.small.pos, state.small.alive, g))[..., None],
             take(_occupancy(state.large.pos, state.large.alive, g))[..., None],
             take(_occupancy(state.predators.pos, state.predators.alive, g))[..., None],
             (~inb).astype(jnp.float32)[..., None]]
    # Social features: each observer sees, in the cell of every other visible agent,
    # its own memory of that agent, the agent's appearance and last token.
    tok = jax.nn.one_hot(state.last_token, N_TOKENS) * (state.last_token >= 0)[:, None]

    def social_window(i):
        rel = state.pos - state.pos[i] + r                             # (N, 2)
        vis = jnp.all((rel >= 0) & (rel < v), axis=-1) & state.alive & (jnp.arange(n) != i)
        feats = jnp.concatenate([jnp.log1p(state.memory[i]), state.appearance, tok], axis=-1)
        feats = jnp.where(vis[:, None], feats, 0.0)
        relc = jnp.clip(rel, 0, v - 1)
        return jnp.zeros((v, v, N_SOCIAL_FEATURES)).at[relc[:, 0], relc[:, 1]].add(feats)

    social = jax.vmap(social_window)(jnp.arange(n))                    # (N, V, V, F)
    win = jnp.concatenate(chans + [social], axis=-1)                   # (N, V, V, C)
    win = win.at[:, r, r, N_TERRAIN + 3].add(-state.alive.astype(jnp.float32))  # not self

    terr_here = state.terrain[state.pos[:, 0], state.pos[:, 1]]
    amb = ambient_temperature(state.t, state.weather, terr_here, cfg)
    day_ph = 2 * jnp.pi * (state.t % cfg.day_length) / cfg.day_length
    yr_ph = 2 * jnp.pi * (state.t % cfg.year_length) / cfg.year_length
    shared = jnp.concatenate([
        jnp.array([jnp.sin(day_ph), jnp.cos(day_ph), jnp.sin(yr_ph), jnp.cos(yr_ph),
                   is_night(state.t, cfg).astype(jnp.float32)]),
        jax.nn.one_hot(state.weather, N_WEATHER)])
    body = jnp.stack([
        state.satiety, state.hydration, state.energy, state.health,
        state.plant_inv / cfg.inventory_cap, state.meat_inv / cfg.inventory_cap,
        state.age / cfg.max_age, state.body_temp, (amb - cfg.comfort_temp) / cfg.temp_scale,
        state.injury, (state.infection > 0).astype(jnp.float32), state.stress,
        state.pain_aversion / 4.0], axis=-1)                           # (N, 13)
    feats = jnp.concatenate([body, jnp.broadcast_to(shared, (n, shared.shape[0]))], axis=-1)
    return jnp.concatenate([win.reshape(n, -1), feats], axis=-1)


def obs_dim(cfg: EnvConfig) -> int:
    return cfg.view_size ** 2 * N_OBS_CHANNELS + N_BODY_FEATURES


# ---------------------------------------------------------------- animals
def _move_animals(key, an: Animals, agent_pos, agent_alive, terrain, notice, act_prob,
                  approach, cfg: EnvConfig):
    """Flee from (approach=False) or chase (approach=True) the nearest agent in
    range; otherwise wander. Water and edges block movement."""
    g = cfg.grid_size
    k_act, k_dir, k_wander = jax.random.split(key, 3)
    d = _cheb(an.pos[:, None, :], agent_pos[None, :, :])
    d = jnp.where(agent_alive[None, :], d, 10 ** 6)
    nearest = jnp.argmin(d, axis=1)
    dist = jnp.min(d, axis=1)
    hunting = (an.rest <= 0) if approach else jnp.ones_like(an.alive)
    engaged = an.alive & (dist <= notice) & hunting
    toward = jnp.sign(agent_pos[nearest] - an.pos)
    step_engaged = toward if approach else -toward
    rand_dir = MOVE_DELTAS[jax.random.randint(k_dir, (an.pos.shape[0],), 0, 9)]
    acts = jax.random.uniform(k_act, (an.pos.shape[0],))
    move_engaged = engaged & (acts < act_prob)
    move_wander = ~engaged & (jax.random.uniform(k_wander, acts.shape) < cfg.wander_prob)
    delta = jnp.where(move_engaged[:, None], step_engaged,
                      jnp.where(move_wander[:, None], rand_dir, 0))
    new = an.pos + delta
    ok = _in_bounds(new, g)
    newc = jnp.clip(new, 0, g - 1)
    ok = ok & (terrain[newc[:, 0], newc[:, 1]] != WATER) & an.alive
    return an._replace(pos=jnp.where(ok[:, None], newc, an.pos)), nearest, dist


def _respawn(key, an: Animals, terrain, prob, hp):
    k_p, k_c = jax.random.split(key)
    born = ~an.alive & (jax.random.uniform(k_p, an.alive.shape) < prob)
    cells = _random_land_cells(k_c, terrain, an.alive.shape[0])
    return Animals(pos=jnp.where(born[:, None], cells, an.pos), alive=an.alive | born,
                   hp=jnp.where(born, hp, an.hp), rest=jnp.where(born, 0, an.rest))


# ---------------------------------------------------------------- step
def step(state: State, actions: jnp.ndarray, cfg: EnvConfig):
    """Resolve one tick for all agents simultaneously.
    Returns (next_state, reward (N,), done (scalar), info: StepInfo)."""
    g, n = cfg.grid_size, cfg.n_agents
    keys = jax.random.split(state.key, 16)
    key = keys[0]
    alive0 = state.alive
    geno = state.genotype
    idx = jnp.arange(n)
    season = season_of(state.t, cfg)
    night = is_night(state.t, cfg)

    # ---------------------------------------------------------- weather
    timer = state.weather_timer - 1
    change = timer <= 0
    extreme = jax.random.uniform(keys[1]) < cfg.climate_volatility
    # Which extremes are possible depends on the season
    extreme_w = jnp.array([[0.0, 0.0, 0.5, 0.5, 0.0],   # spring: drought, cold
                           [0.0, 0.0, 0.5, 0.0, 0.5],   # summer: drought, heat
                           [0.0, 0.0, 0.5, 0.5, 0.0],   # autumn
                           [0.0, 0.0, 0.0, 1.0, 0.0]])[season]
    mild_w = jnp.array([0.6, 0.4, 0.0, 0.0, 0.0])
    probs = jnp.where(extreme, extreme_w, mild_w)
    new_weather = jax.random.choice(keys[2], N_WEATHER, p=probs)
    weather = jnp.where(change, new_weather, state.weather).astype(jnp.int32)
    dur = jax.random.randint(keys[3], (), cfg.spell_min, cfg.spell_max)
    timer = jnp.where(change, dur, timer).astype(jnp.int32)
    weather_changed = change & (weather != state.weather)

    # ---------------------------------------------------------- decode actions
    mask = action_mask(state, cfg)
    valid = jnp.take_along_axis(mask, actions[:, None], axis=1)[:, 0]
    a = jnp.where(valid & alive0, actions, REST)
    is_move = (a >= MOVE_N) & (a <= MOVE_NW)
    is_strike = (a >= STRIKE_N) & (a < STRIKE_N + 8)
    resting = a == REST

    # Capability modifiers: senescence and injury
    life_frac = state.age / (cfg.max_age * geno.lifespan)
    vigor = jnp.clip(1.0 - jnp.maximum(life_frac - cfg.senescence_start, 0.0)
                     / (1.0 - cfg.senescence_start) * 0.5, 0.5, 1.0)

    # ---------------------------------------------------------- movement
    move_fail = jax.random.uniform(keys[4], (n,)) < state.injury * cfg.injury_move_fail
    moving = is_move & ~move_fail
    new_pos = jnp.where(moving[:, None], state.pos + MOVE_DELTAS[jnp.where(is_move, a, 0)],
                        state.pos)
    terr_new = state.terrain[new_pos[:, 0], new_pos[:, 1]]
    move_energy = jnp.where(moving, cfg.move_cost * TERRAIN_MOVE_COST[terr_new]
                            * (1 + state.injury) / (geno.speed * vigor), 0.0)
    fell = moving & (terr_new == ROCK) & (jax.random.uniform(keys[5], (n,)) < cfg.rock_fall_prob)
    injury = state.injury + jnp.where(fell, cfg.rock_fall_injury, 0.0)

    # ---------------------------------------------------------- strikes
    sdir = jnp.where(is_strike, a - STRIKE_N + 1, 0)
    tgt = state.pos + MOVE_DELTAS[sdir]
    tgt_ok = is_strike & _in_bounds(tgt, g)
    tgt = jnp.clip(tgt, 0, g - 1)
    occ_pred = _occupancy(state.predators.pos, state.predators.alive, g)
    occ_large = _occupancy(state.large.pos, state.large.alive, g)
    occ_small = _occupancy(state.small.pos, state.small.alive, g)
    occ_agent = _occupancy(state.pos, alive0, g)
    tr, tc = tgt[:, 0], tgt[:, 1]
    hit_pred = tgt_ok & (occ_pred[tr, tc] > 0)
    hit_large = tgt_ok & ~hit_pred & (occ_large[tr, tc] > 0)
    hit_small = tgt_ok & ~hit_pred & ~hit_large & (occ_small[tr, tc] > 0)
    hit_agent = tgt_ok & ~hit_pred & ~hit_large & ~hit_small & (occ_agent[tr, tc] > 0)
    dmg = cfg.strike_damage * geno.strength * vigor * (1 - 0.5 * state.injury)

    def dmg_grid(hit):
        return jnp.zeros((g, g)).at[tr, tc].add(jnp.where(hit, dmg, 0.0))

    def wound(an: Animals, grid, armor):
        taken = jnp.maximum(grid[an.pos[:, 0], an.pos[:, 1]] - armor, 0.0)
        hp = an.hp - jnp.where(an.alive, taken, 0.0)
        killed = an.alive & (hp <= 0)
        return an._replace(hp=hp, alive=an.alive & ~killed), killed, taken

    predators, killed_pred, pred_taken = wound(state.predators, dmg_grid(hit_pred), cfg.predator_armor)
    large, killed_large, _ = wound(state.large, dmg_grid(hit_large), cfg.large_prey_armor)
    small, killed_small, _ = wound(state.small, dmg_grid(hit_small), 0.0)
    meat = state.meat
    meat = meat.at[large.pos[:, 0], large.pos[:, 1]].add(jnp.where(killed_large, cfg.large_prey_meat, 0.0))
    meat = meat.at[small.pos[:, 0], small.pos[:, 1]].add(jnp.where(killed_small, cfg.small_prey_meat, 0.0))

    def kill_credit(killed, an, hit):
        """Every striker who hit a cell where an animal died gets credit."""
        kgrid = jnp.zeros((g, g)).at[an.pos[:, 0], an.pos[:, 1]].add(killed.astype(jnp.float32))
        return hit & (kgrid[tr, tc] > 0)

    kills = jnp.stack([kill_credit(killed_small, small, hit_small),
                       kill_credit(killed_large, large, hit_large),
                       kill_credit(killed_pred, predators, hit_pred)], axis=-1)
    agent_dmg_grid = dmg_grid(hit_agent)
    violence = jnp.where(alive0, agent_dmg_grid[state.pos[:, 0], state.pos[:, 1]], 0.0)
    struck_by_agent = violence > 0
    injury = injury + 0.5 * violence

    # ---------------------------------------------------------- animals act
    pos_after = jnp.where(alive0[:, None], new_pos, state.pos)
    small, _, _ = _move_animals(keys[6], small, pos_after, alive0, state.terrain,
                                cfg.small_prey_notice, cfg.small_prey_flee_prob, False, cfg)
    large, _, _ = _move_animals(keys[7], large, pos_after, alive0, state.terrain,
                                cfg.large_prey_notice, cfg.large_prey_flee_prob, False, cfg)
    predators, target, pdist = _move_animals(keys[8], predators, pos_after, alive0, state.terrain,
                                             cfg.predator_notice, cfg.predator_chase_prob, True, cfg)
    # Predator attacks: adjacent hunting predators attack their target unless it is in a group
    pdist = _cheb(predators.pos, pos_after[target])
    group = jnp.sum((_cheb(pos_after[target][:, None, :], pos_after[None, :, :]) <= 1)
                    & alive0[None, :], axis=1)
    can_attack = predators.alive & (predators.rest <= 0) & (pdist <= 1) & alive0[target]
    deterred = can_attack & (group >= 2)
    attack = can_attack & ~deterred & (jax.random.uniform(keys[9], target.shape) < cfg.predator_attack_prob)
    n_attacks = jnp.zeros(n).at[target].add(attack.astype(jnp.float32))
    predation = n_attacks * cfg.predator_attack_damage
    attacked = n_attacks > 0
    injury = injury + n_attacks * cfg.predator_attack_injury
    rest = jnp.where(attack | deterred, cfg.predator_rest_ticks, jnp.maximum(predators.rest - 1, 0))
    predators = predators._replace(rest=rest)
    # Predators also take small prey on their cell
    pred_cell = _occupancy(predators.pos, predators.alive, g)
    eaten_by_pred = small.alive & (pred_cell[small.pos[:, 0], small.pos[:, 1]] > 0) & \
        (jax.random.uniform(keys[10], small.alive.shape) < cfg.predator_prey_kill_prob)
    small = small._replace(alive=small.alive & ~eaten_by_pred)

    # ---------------------------------------------------------- gathering (contested)
    gathering = a == GRASP
    cid = state.pos[:, 0] * g + state.pos[:, 1]
    score = jnp.where(gathering, geno.strength * jax.random.uniform(keys[11], (n,)), -1.0)
    best = jax.ops.segment_max(score, cid, num_segments=g * g)
    winner = gathering & (score >= best[cid]) & (score > 0)
    r0, c0 = state.pos[:, 0], state.pos[:, 1]
    room = cfg.inventory_cap - state.plant_inv - state.meat_inv
    meat_here = meat[r0, c0]
    take_meat = jnp.where(winner & (meat_here > 0.1),
                          jnp.minimum(jnp.minimum(meat_here, cfg.gather_amount), room), 0.0)
    take_plant = jnp.where(winner & (meat_here <= 0.1),
                           jnp.minimum(jnp.minimum(state.plants[r0, c0], cfg.gather_amount), room), 0.0)
    meat = jnp.maximum(meat.at[r0, c0].add(-take_meat), 0.0)
    plants = jnp.maximum(state.plants.at[r0, c0].add(-take_plant), 0.0)
    meat_inv = state.meat_inv + take_meat
    plant_inv = state.plant_inv + take_plant

    # ---------------------------------------------------------- eat / drink
    eating = a == EAT
    eat_meat = jnp.where(eating, jnp.minimum(meat_inv, 1.0), 0.0)
    eat_plant = jnp.where(eating & (eat_meat <= 0), jnp.minimum(plant_inv, 1.0), 0.0)
    meat_inv, plant_inv = meat_inv - eat_meat, plant_inv - eat_plant
    satiety = state.satiety + eat_meat * cfg.meat_food_value + eat_plant * cfg.plant_food_value
    drinking = a == DRINK
    hydration = state.hydration + jnp.where(drinking, cfg.drink_value, 0.0)

    # ---------------------------------------------------------- social primitives
    not_self = ~jnp.eye(n, dtype=bool)
    same_cell = jnp.all(tgt[:, None, :] == state.pos[None, :, :], axis=-1)   # strike target == j
    hits = hit_agent[:, None] & same_cell & alive0[None, :] & not_self
    # Release: drop one unit (meat first) on the current cell; agents adjacent see a gift
    releasing = a == RELEASE
    drop_meat = jnp.where(releasing, jnp.minimum(meat_inv, 1.0), 0.0)
    drop_plant = jnp.where(releasing & (drop_meat <= 0.05), jnp.minimum(plant_inv, 1.0), 0.0)
    meat_inv, plant_inv = meat_inv - drop_meat, plant_inv - drop_plant
    meat = meat.at[r0, c0].add(drop_meat)
    plants = plants.at[r0, c0].add(drop_plant)
    adjacent = (_cheb(state.pos[:, None, :], state.pos[None, :, :]) <= 1) & not_self
    gifts = releasing[:, None] & adjacent & alive0[None, :] & ((drop_meat + drop_plant) > 0)[:, None]
    # Touch
    is_touch = (a >= TOUCH_N) & (a < TOUCH_N + 8)
    tdir = jnp.where(is_touch, a - TOUCH_N + 1, 0)
    ttgt = state.pos + MOVE_DELTAS[tdir]
    touches = is_touch[:, None] & jnp.all(ttgt[:, None, :] == state.pos[None, :, :], axis=-1) \
        & alive0[None, :] & not_self
    # Tokens
    is_token = a >= TOKEN_0
    token = jnp.where(is_token & alive0, a - TOKEN_0, -1).astype(jnp.int32)
    # Relationship memory: observer (row) about actor (column)
    seeing = (_cheb(state.pos[:, None, :], state.pos[None, :, :]) <= cfg.view_radius) \
        & not_self & alive0[:, None]                                   # k can see j
    witnessed = seeing.astype(jnp.float32) @ hits.T.astype(jnp.float32)  # [k, i]: k saw i strike someone
    witnessed = witnessed * not_self                                   # a striker does not witness itself
    mem_inc = jnp.stack([hits.T, gifts.T, touches.T], axis=-1).astype(jnp.float32)
    mem_inc = jnp.concatenate([mem_inc, witnessed[..., None]], axis=-1)
    memory = state.memory * cfg.memory_decay + mem_inc * alive0[:, None, None]

    # ---------------------------------------------------------- disease
    susceptibility = (1 - state.immunity) / geno.disease_resistance
    water_risk = cfg.water_infection * jnp.where(weather == DROUGHT, 2.0, 1.0)
    infected_now = state.infection > 0
    near = (_cheb(pos_after[:, None, :], pos_after[None, :, :]) <= 1) & ~jnp.eye(n, dtype=bool)
    sick_neighbors = jnp.sum(near & (infected_now & alive0)[None, :], axis=1)
    p_inf = 1 - (1 - jnp.where(eat_meat > 0, cfg.raw_meat_infection, 0.0)) \
        * (1 - jnp.where(drinking, water_risk, 0.0)) \
        * (1 - cfg.contact_infection) ** sick_neighbors
    newly_infected = alive0 & ~infected_now & \
        (jax.random.uniform(keys[12], (n,)) < jnp.clip(p_inf * susceptibility, 0.0, 1.0))
    infection = jnp.where(newly_infected, cfg.disease_duration,
                          jnp.maximum(state.infection - 1, 0)).astype(jnp.int32)
    recovered = alive0 & infected_now & (infection == 0)
    immunity = jnp.where(recovered, 1.0, jnp.maximum(state.immunity - cfg.immunity_decay, 0.0))
    sick = infection > 0

    # ---------------------------------------------------------- temperature
    terr_here = state.terrain[pos_after[:, 0], pos_after[:, 1]]
    amb = ambient_temperature(state.t, weather, terr_here, cfg)
    load = (amb - cfg.comfort_temp) / cfg.temp_scale + jnp.where(resting, cfg.rest_warmth, 0.0)
    load = load + jnp.where(moving, 0.05, 0.0)               # activity produces heat
    huddle = jnp.minimum(jnp.sum(near & alive0[None, :], axis=1), 3)
    load = load + cfg.huddle_warmth * huddle                   # body heat of neighbors
    body_temp = state.body_temp + cfg.thermal_rate / geno.insulation * (load - state.body_temp)
    body_temp = jnp.clip(body_temp, -1.5, 1.5)

    # ---------------------------------------------------------- metabolism
    hunger = cfg.hunger_rate * geno.metabolism * (1 + jnp.where(sick, cfg.disease_hunger_mult, 0.0))
    thirst = cfg.thirst_rate * jnp.where(weather == DROUGHT, cfg.drought_thirst_mult, 1.0) \
        * (1 + cfg.sweat_thirst_mult * jnp.maximum(body_temp - 0.2, 0.0))
    rest_gain = jnp.where(resting, cfg.rest_recovery * jnp.where(night, cfg.night_rest_bonus, 1.0), 0.0)
    energy = state.energy + rest_gain - jnp.where(resting, 0.0, cfg.fatigue_rate) - move_energy \
        - jnp.where(sick, cfg.disease_fatigue, 0.0) - cfg.stress_energy_cost * state.stress
    satiety = jnp.clip(satiety - hunger, 0.0, 1.0)
    hydration = jnp.clip(hydration - thirst, 0.0, 1.0)
    energy = jnp.clip(energy, 0.0, 1.0)

    # ---------------------------------------------------------- damage and healing
    injury = jnp.clip(injury, 0.0, 1.0)
    components = jnp.stack([
        jnp.where(satiety <= 0, cfg.starve_damage, 0.0),
        jnp.where(hydration <= 0, cfg.thirst_damage, 0.0),
        jnp.where(energy <= 0, cfg.exhaust_damage, 0.0),
        jnp.where(body_temp < cfg.cold_threshold, cfg.cold_damage, 0.0),
        jnp.where(body_temp > cfg.heat_threshold, cfg.heat_damage, 0.0),
        jnp.where(sick, cfg.disease_damage / geno.disease_resistance, 0.0),
        predation,
        violence,
        cfg.injury_bleed * jnp.maximum(injury - 0.5, 0.0) * 2,
    ], axis=-1)
    damage = components.sum(-1)
    thriving = (satiety > 0.3) & (hydration > 0.3) & (energy > 0.3) & ~sick \
        & (state.stress < cfg.stress_heal_block)
    health = jnp.clip(state.health - damage + jnp.where(thriving, cfg.heal_rate, 0.0), 0.0, 1.0)
    health = jnp.where(alive0, health, state.health)
    health_loss = jnp.maximum(state.health - health, 0.0)
    injury = jnp.clip(injury - jnp.where(thriving, cfg.injury_heal_rate, 0.0), 0.0, 1.0)

    # ---------------------------------------------------------- psychology
    pred_near = jnp.any((_cheb(pos_after[:, None, :], predators.pos[None]) <= 3)
                        & predators.alive[None, :], axis=1)
    critical = ((satiety < 0.15).astype(jnp.float32) + (hydration < 0.15) + (energy < 0.15)
                + (body_temp < cfg.cold_threshold) + (body_temp > cfg.heat_threshold))
    stress = state.stress * cfg.stress_decay + cfg.stress_from_damage * health_loss \
        + jnp.where(pred_near, cfg.stress_from_threat, 0.0) + cfg.stress_from_need * critical
    stress = jnp.clip(stress, 0.0, 1.0)
    pain_aversion = state.pain_aversion + geno.temperament_drift * cfg.trauma_rate * health_loss \
        - cfg.trauma_recovery * geno.temperament_drift * (state.pain_aversion - geno.pain_aversion)
    pain_aversion = jnp.clip(pain_aversion, 0.25, 4.0)

    # ---------------------------------------------------------- aging and death
    age = state.age + alive0.astype(jnp.int32)
    old = age >= (cfg.max_age * geno.lifespan).astype(jnp.int32)
    dead_now = alive0 & ((health <= 0.0) | old)
    alive = alive0 & ~dead_now
    cause = jnp.where(old, CAUSE_AGE, 1 + jnp.argmax(components, axis=-1))
    cause = jnp.where(dead_now, cause, CAUSE_NONE)

    # ---------------------------------------------------------- world dynamics
    regrow = jnp.array([*SEASON_REGROW, cfg.winter_regrow_factor])[season]
    regrow = regrow * jnp.where(weather == RAIN, cfg.rain_regrow_mult,
                                jnp.where(weather == DROUGHT, cfg.drought_regrow_mult, 1.0))
    base_rate = jnp.where(state.terrain == FOREST, cfg.plant_regrow_forest,
                          jnp.where(state.terrain == GRASS, cfg.plant_regrow_grass, 0.0))
    plants = jnp.minimum(plants + base_rate * regrow, cfg.plant_max)
    meat = meat * (1 - cfg.meat_spoil_ground)
    meat_inv = meat_inv * (1 - cfg.meat_spoil_inventory)
    breed = regrow                                       # animals breed with plant growth
    small = _respawn(keys[13], small, state.terrain, cfg.small_prey_respawn * breed, cfg.small_prey_hp)
    large = _respawn(keys[14], large, state.terrain, cfg.large_prey_respawn * breed, cfg.large_prey_hp)
    predators = _respawn(keys[15], predators, state.terrain, cfg.predator_respawn, cfg.predator_hp)
    small = small._replace(hp=jnp.minimum(small.hp + cfg.animal_hp_regen, cfg.small_prey_hp))
    large = large._replace(hp=jnp.minimum(large.hp + cfg.animal_hp_regen, cfg.large_prey_hp))
    predators = predators._replace(hp=jnp.minimum(predators.hp + cfg.animal_hp_regen, cfg.predator_hp))

    # ---------------------------------------------------------- novelty
    new_cell = alive & ~state.visited[idx, pos_after[:, 0], pos_after[:, 1]]
    visited = state.visited.at[idx, pos_after[:, 0], pos_after[:, 1]].set(
        state.visited[idx, pos_after[:, 0], pos_after[:, 1]] | alive)

    # ---------------------------------------------------------- reward
    reward = (jnp.where(alive, cfg.alive_reward, 0.0)
              - jnp.where(dead_now, cfg.death_penalty, 0.0)
              - state.pain_aversion * health_loss
              + jnp.where(new_cell, cfg.novelty_reward * geno.novelty, 0.0)
              + cfg.touch_reward * geno.social_reward
              * (jnp.any(touches, axis=1) | jnp.any(touches, axis=0)).astype(jnp.float32))

    # ---------------------------------------------------------- outcomes
    any_kill = jnp.any(kills, axis=-1)
    outcome = jnp.select(
        [~alive0, resting, is_move & move_fail, is_move, winner, gathering, eating, drinking,
         any_kill, hit_agent, hit_pred | hit_large | hit_small, is_strike,
         releasing, is_touch, is_token],
        [OUT_NONE, OUT_REST, OUT_MOVE_FAILED, OUT_MOVE, OUT_GATHER, OUT_GATHER_LOST, OUT_EAT,
         OUT_DRINK, OUT_KILL, OUT_STRIKE_AGENT, OUT_STRIKE_ANIMAL, OUT_STRIKE_MISS,
         OUT_RELEASE, OUT_TOUCH, OUT_TOKEN], OUT_NONE)

    def keep(new, old):
        return jnp.where(alive0, new, old)

    t = state.t + 1
    next_state = State(
        key=key, t=t, terrain=state.terrain, plants=plants, meat=meat,
        weather=weather, weather_timer=timer, pos=pos_after,
        satiety=keep(satiety, state.satiety), hydration=keep(hydration, state.hydration),
        energy=keep(energy, state.energy), health=health,
        plant_inv=plant_inv, meat_inv=meat_inv, age=age, alive=alive, visited=visited,
        body_temp=keep(body_temp, state.body_temp), injury=keep(injury, state.injury),
        infection=jnp.where(alive0, infection, state.infection),
        immunity=keep(immunity, state.immunity), stress=keep(stress, state.stress),
        pain_aversion=keep(pain_aversion, state.pain_aversion), genotype=geno,
        appearance=state.appearance, memory=memory, last_token=token,
        small=small, large=large, predators=predators,
    )
    done = (~jnp.any(alive)) | (t >= cfg.max_steps)
    info = StepInfo(
        outcome=outcome, died=dead_now, death_cause=cause,
        gathered=take_meat + take_plant, health_loss=health_loss, pos=pos_after, t=state.t,
        attacked_by_predator=attacked, struck_by_agent=struck_by_agent,
        newly_infected=newly_infected, recovered=recovered, fell=fell, kills=kills,
        weather=weather, weather_changed=weather_changed, ambient_temp=amb,
        hits=hits, gifts=gifts, touches=touches, token=token)
    return next_state, reward, done, info
