"""Event-sourced recording: an append-only event log, periodic full-state
snapshots, and the action log needed for exact replay.

Rewind = load the nearest earlier snapshot, then replay logged actions forward.
Actions are always logged (not regenerated), so replay stays exact even when
the policy is stochastic or runs on nondeterministic hardware.
"""
from __future__ import annotations

import json
import pickle
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import jax
import jax.numpy as jnp
import numpy as np

from . import env as E
from .config import EnvConfig

# policy_fn(key, obs (N, D), mask (N, A), carry) -> (actions (N,), new_carry)
PolicyFn = Callable


@dataclass
class Recording:
    cfg: EnvConfig
    seed: int
    snapshot_every: int
    snapshots: dict = field(default_factory=dict)   # tick -> State (numpy leaves)
    actions: list = field(default_factory=list)     # per tick: (N,) int array
    events: list = field(default_factory=list)      # list of event dicts

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        with open(path / "events.jsonl", "w") as f:
            for ev in self.events:
                f.write(json.dumps(ev) + "\n")
        np.save(path / "actions.npy", np.stack(self.actions) if self.actions else np.zeros((0,)))
        with open(path / "snapshots.pkl", "wb") as f:
            pickle.dump({"cfg": self.cfg, "seed": self.seed,
                         "snapshot_every": self.snapshot_every,
                         "snapshots": self.snapshots}, f)


def _to_numpy(tree):
    return jax.tree_util.tree_map(np.asarray, tree)


def _to_jax(tree):
    return jax.tree_util.tree_map(jnp.asarray, tree)


ANIMAL_NAMES = ["small_prey", "large_prey", "predator"]


def extract_events(info: E.StepInfo, actions: np.ndarray, prev_last_event: dict) -> list:
    """Convert one step's StepInfo into event records.

    Each event carries `parents`: ids of earlier events it causally depends on.
    A death links to the agent's most recent recorded event (often the attack,
    infection or fall that caused it). Richer links come with Phase 2.
    """
    info = _to_numpy(info)
    t = int(info.t)
    events = []

    def emit(i, kind, **extra):
        ev = {"id": f"{t}:{i}:{kind}", "t": t, "agent": int(i), "type": kind,
              "pos": [int(info.pos[i, 0]), int(info.pos[i, 1])], "parents": [], **extra}
        events.append(ev)
        prev_last_event[i] = ev["id"]
        return ev

    if bool(info.weather_changed):
        events.append({"id": f"{t}:world:weather", "t": t, "agent": -1, "type": "weather",
                       "weather": E.WEATHER_NAMES[int(info.weather)], "parents": []})
    for i in range(len(info.outcome)):
        code = int(info.outcome[i])
        if code == E.OUT_GATHER:
            emit(i, "gather", amount=round(float(info.gathered[i]), 4))
        elif code == E.OUT_STRIKE_AGENT:
            emit(i, "strike_agent", victims=np.flatnonzero(info.hits[i]).tolist())
        elif code == E.OUT_RELEASE:
            emit(i, "release", near=np.flatnonzero(info.gifts[i]).tolist())
        elif code == E.OUT_TOUCH and info.touches[i].any():
            emit(i, "touch", targets=np.flatnonzero(info.touches[i]).tolist())
        elif code in (E.OUT_GATHER_LOST, E.OUT_EAT, E.OUT_DRINK,
                      E.OUT_STRIKE_ANIMAL, E.OUT_MOVE_FAILED):
            emit(i, E.OUTCOME_NAMES[code])
        for k, name in enumerate(ANIMAL_NAMES):
            if bool(info.kills[i, k]):
                emit(i, "kill", animal=name)
        if bool(info.attacked_by_predator[i]):
            emit(i, "predator_attack", health_loss=round(float(info.health_loss[i]), 4))
        if bool(info.struck_by_agent[i]):
            emit(i, "struck_by_agent")
        if bool(info.fell[i]):
            emit(i, "fall")
        if bool(info.newly_infected[i]):
            emit(i, "infected")
        if bool(info.recovered[i]):
            emit(i, "recovered")
        if bool(info.died[i]):
            parent = prev_last_event.get(i)
            ev = emit(i, "death", cause=E.CAUSE_NAMES[int(info.death_cause[i])])
            ev["parents"] = [parent] if parent else []
    return events


def record_episode(policy_fn: PolicyFn, carry, seed: int, cfg: EnvConfig,
                   snapshot_every: int = 100, max_steps: int | None = None) -> Recording:
    """Run one episode on the host, logging events, actions and snapshots."""
    key = jax.random.PRNGKey(seed)
    k_env, k_pol = jax.random.split(key)
    state = E.reset(k_env, cfg)
    step_fn = jax.jit(lambda s, a: E.step(s, a, cfg))
    obs_fn = jax.jit(lambda s: (E.observe(s, cfg), E.action_mask(s, cfg)))
    rec = Recording(cfg=cfg, seed=seed, snapshot_every=snapshot_every)
    last_event: dict = {}
    for t in range(max_steps or cfg.max_steps):
        if t % snapshot_every == 0:
            rec.snapshots[t] = _to_numpy(state)
        obs, mask = obs_fn(state)
        k_pol, k = jax.random.split(k_pol)
        actions, carry = policy_fn(k, obs, mask, carry)
        state, _, done, info = step_fn(state, actions)
        rec.actions.append(np.asarray(actions))
        rec.events.extend(extract_events(info, np.asarray(actions), last_event))
        if bool(done):
            break
    rec.snapshots[int(state.t)] = _to_numpy(state)
    return rec


def rewind(rec: Recording, tick: int) -> E.State:
    """Exact world state at `tick`: nearest earlier snapshot + replayed actions."""
    base = max(t for t in rec.snapshots if t <= tick)
    state = _to_jax(rec.snapshots[base])
    step_fn = jax.jit(lambda s, a: E.step(s, a, rec.cfg))
    for t in range(base, tick):
        state, *_ = step_fn(state, jnp.asarray(rec.actions[t]))
    return state


def random_policy(key, obs, mask, carry):
    """Uniform over valid actions. Useful as a baseline and for tests."""
    logits = jnp.where(mask, 0.0, -1e9)
    return jax.random.categorical(key, logits), carry
