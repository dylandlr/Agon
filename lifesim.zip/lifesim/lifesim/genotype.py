"""Heritable traits. Genes encode drives, capacities and learning biases,
never concepts or behaviors. All traits are float arrays of shape (n_agents,)."""
from __future__ import annotations

from typing import NamedTuple

import jax
import jax.numpy as jnp


class Genotype(NamedTuple):
    # Physical: multipliers around 1.0
    strength: jnp.ndarray
    speed: jnp.ndarray
    metabolism: jnp.ndarray       # higher = gets hungry faster
    lifespan: jnp.ndarray
    disease_resistance: jnp.ndarray  # scales infection chance and severity down
    insulation: jnp.ndarray       # slows body-temperature drift toward ambient
    # Temperament: weights on intrinsic reward terms
    pain_aversion: jnp.ndarray    # weight on health loss
    social_reward: jnp.ndarray    # weight on social contact (unused until Phase 2)
    novelty: jnp.ndarray          # weight on visiting new cells
    patience: jnp.ndarray         # discount factor gamma in [0.95, 0.999]
    # Plasticity
    lr_scale: jnp.ndarray         # multiplies optimizer learning rate
    critical_period: jnp.ndarray  # ticks over which learning rate decays
    social_learning: jnp.ndarray  # imitation loss weight (unused until Phase 2)
    temperament_drift: jnp.ndarray  # how far experience shifts temperament phenotype


# (log-mean, log-std) for multiplicative traits; (low, high) for bounded ones
_LOGNORMAL = {
    "strength": 0.15, "speed": 0.15, "metabolism": 0.15, "lifespan": 0.10,
    "disease_resistance": 0.20, "insulation": 0.15,
    "pain_aversion": 0.30, "social_reward": 0.30, "novelty": 0.30,
    "lr_scale": 0.30,
}
_BOUNDS = {
    "patience": (0.95, 0.999),
    "critical_period": (2000.0, 20000.0),
    "social_learning": (0.0, 1.0),
    "temperament_drift": (0.0, 1.0),
}
_FIELDS = Genotype._fields


def sample(key: jax.Array, n: int) -> Genotype:
    """Founder genotypes: independent draws per trait."""
    keys = jax.random.split(key, len(_FIELDS))
    vals = {}
    for k, name in zip(keys, _FIELDS):
        if name in _LOGNORMAL:
            vals[name] = jnp.exp(_LOGNORMAL[name] * jax.random.normal(k, (n,)))
        else:
            lo, hi = _BOUNDS[name]
            vals[name] = jax.random.uniform(k, (n,), minval=lo, maxval=hi)
    return Genotype(**vals)


def clip(g: Genotype) -> Genotype:
    """Keep traits in biologically sane ranges after mutation."""
    vals = {}
    for name in _FIELDS:
        v = getattr(g, name)
        if name in _LOGNORMAL:
            vals[name] = jnp.clip(v, 0.25, 4.0)
        else:
            lo, hi = _BOUNDS[name]
            vals[name] = jnp.clip(v, lo, hi)
    return Genotype(**vals)


def recombine_and_mutate(key: jax.Array, mother: Genotype, father: Genotype,
                         mutation_scale: float = 0.05) -> Genotype:
    """Per-trait uniform crossover, then multiplicative (or additive, for
    bounded traits) Gaussian mutation. Shapes must match."""
    k_cross, k_mut = jax.random.split(key)
    cross_keys = jax.random.split(k_cross, len(_FIELDS))
    mut_keys = jax.random.split(k_mut, len(_FIELDS))
    vals = {}
    for ck, mk, name in zip(cross_keys, mut_keys, _FIELDS):
        m, f = getattr(mother, name), getattr(father, name)
        pick = jax.random.bernoulli(ck, 0.5, m.shape)
        child = jnp.where(pick, m, f)
        noise = jax.random.normal(mk, m.shape)
        if name in _LOGNORMAL:
            child = child * jnp.exp(mutation_scale * noise)
        else:
            lo, hi = _BOUNDS[name]
            child = child + mutation_scale * (hi - lo) * noise
        vals[name] = child
    return clip(Genotype(**vals))
