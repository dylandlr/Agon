"""Phase 2: N individuals with their own networks share a world (in B replica
worlds). Logs social behavior rates per 1000 living agent-ticks.

    python scripts/train_phase2.py --agents 8 --worlds 16 --ticks 400000 --out runs/p2
    python scripts/train_phase2.py --scarcity 0.4 --out runs/p2_scarce   # E1-style dial
"""
from __future__ import annotations

import argparse
import json
import pickle
import time
from pathlib import Path

import jax
import numpy as np

from lifesim import env as E
from lifesim.config import EnvConfig
from lifesim.ppo_multi import MAConfig, make_train


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--agents", type=int, default=8)
    ap.add_argument("--worlds", type=int, default=16)
    ap.add_argument("--ticks", type=int, default=200_000)
    ap.add_argument("--steps", type=int, default=128)
    ap.add_argument("--grid", type=int, default=64)
    ap.add_argument("--scarcity", type=float, default=1.0, help="multiplier on plant regrowth")
    ap.add_argument("--encoder", choices=["conv", "mlp"], default="conv")
    ap.add_argument("--gamma", type=float, default=0.997)
    ap.add_argument("--trait-gamma", action="store_true")
    ap.add_argument("--no-agent-lr", action="store_true")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--log-every", type=int, default=10)
    ap.add_argument("--out", type=str, default="runs/phase2")
    args = ap.parse_args()

    base = EnvConfig()
    env_cfg = EnvConfig(grid_size=args.grid, n_agents=args.agents,
                        plant_regrow_forest=base.plant_regrow_forest * args.scarcity,
                        plant_regrow_grass=base.plant_regrow_grass * args.scarcity)
    cfg = MAConfig(num_worlds=args.worlds, num_steps=args.steps, total_ticks=args.ticks,
                   encoder=args.encoder, gamma=args.gamma, trait_gamma=args.trait_gamma,
                   per_agent_lr=not args.no_agent_lr, seed=args.seed,
                   num_minibatches=min(4, args.worlds))
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    net, init, update = make_train(env_cfg, cfg)
    runner, pop = init(jax.random.PRNGKey(cfg.seed))
    history, acc = [], None
    t0 = time.time()
    for u in range(cfg.num_updates):
        runner, m = update(runner, pop)
        m = jax.tree_util.tree_map(np.asarray, m)
        acc = m if acc is None else jax.tree_util.tree_map(lambda a, x: a + x, acc, m)
        if (u + 1) % args.log_every == 0 or u == cfg.num_updates - 1:
            alive = max(float(acc["alive"]), 1.0)
            deaths = float(acc["deaths"])
            per_k = lambda x: round(1000 * float(x) / alive, 3)
            row = {
                "update": u + 1, "ticks": (u + 1) * cfg.num_steps,
                "agent_steps": (u + 1) * cfg.num_steps * cfg.num_worlds * args.agents,
                "mean_age_at_death": round(float(acc["age_at_death"]) / deaths, 1) if deaths else None,
                "deaths": {E.CAUSE_NAMES[c]: int(k) for c, k in enumerate(acc["cause"]) if c and k},
                "per_1000_agent_ticks": {"strikes_on_agents": per_k(acc["hits"]),
                                         "gifts": per_k(acc["gifts"]),
                                         "touches": per_k(acc["touches"]),
                                         "tokens": per_k(acc["tokens"])},
                "kills": {"small_prey": int(acc["kills"][0]), "large_prey": int(acc["kills"][1]),
                          "predator": int(acc["kills"][2])},
                "entropy": round(float(m["entropy"]) / max(1, 1), 3),
                "agent_sps": round((u + 1) * cfg.num_steps * cfg.num_worlds * args.agents
                                   / (time.time() - t0), 1),
            }
            history.append(row)
            print(json.dumps(row), flush=True)
            acc = None
    from flax import serialization
    (out / "params.msgpack").write_bytes(serialization.to_bytes(runner[0]))
    with open(out / "population.pkl", "wb") as f:
        pickle.dump(jax.tree_util.tree_map(np.asarray, pop), f)
    json.dump({"args": vars(args), "history": history}, open(out / "history.json", "w"), indent=1)
    print(f"saved to {out}")


if __name__ == "__main__":
    main()
