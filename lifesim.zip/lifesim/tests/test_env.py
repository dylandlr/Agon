import jax
import jax.numpy as jnp
import numpy as np

from lifesim import env as E
from lifesim import genotype as gt
from lifesim.config import EnvConfig
from lifesim.recorder import random_policy, record_episode, rewind

CFG = EnvConfig(grid_size=24, n_agents=4, max_steps=300)


def _rollout(seed, cfg=CFG, steps=200):
    key = jax.random.PRNGKey(seed)
    state = E.reset(key, cfg)
    step = jax.jit(lambda s, a: E.step(s, a, cfg))
    k = jax.random.PRNGKey(seed + 1)
    for _ in range(steps):
        k, sk = jax.random.split(k)
        a, _ = random_policy(sk, None, E.action_mask(state, cfg), None)
        state, *_ = step(state, a)
    return state


def test_determinism_same_seed():
    s1, s2 = _rollout(3), _rollout(3)
    for a, b in zip(jax.tree_util.tree_leaves(s1), jax.tree_util.tree_leaves(s2)):
        np.testing.assert_array_equal(np.asarray(a), np.asarray(b))


def test_different_seeds_differ():
    s1, s2 = _rollout(3), _rollout(4)
    assert not np.array_equal(np.asarray(s1.terrain), np.asarray(s2.terrain))


def test_terrain_has_all_types_and_spawns_on_land():
    for seed in range(5):
        s = E.reset(jax.random.PRNGKey(seed), EnvConfig(grid_size=32, n_agents=50))
        types = set(np.unique(np.asarray(s.terrain)).tolist())
        assert types == {E.GRASS, E.FOREST, E.ROCK, E.WATER}
        terr_at = np.asarray(s.terrain)[np.asarray(s.pos[:, 0]), np.asarray(s.pos[:, 1])]
        assert not np.any(terr_at == E.WATER)


def test_masked_moves_never_enter_water_or_leave_grid():
    s = _rollout(7, steps=300)
    p = np.asarray(s.pos)
    assert np.all((p >= 0) & (p < CFG.grid_size))
    assert not np.any(np.asarray(s.terrain)[p[:, 0], p[:, 1]] == E.WATER)


def test_invalid_action_becomes_rest():
    s = E.reset(jax.random.PRNGKey(0), CFG)
    s = s._replace(plant_inv=jnp.zeros(CFG.n_agents), meat_inv=jnp.zeros(CFG.n_agents))
    s2, _, _, info = E.step(s, jnp.full((CFG.n_agents,), E.EAT), CFG)
    assert np.all(np.asarray(info.outcome) == E.OUT_REST)


def test_contested_gather_single_winner_and_conservation():
    cfg = EnvConfig(grid_size=12, n_agents=3, max_steps=10)
    s = E.reset(jax.random.PRNGKey(1), cfg)
    s = s._replace(meat=jnp.zeros_like(s.meat))
    land = np.argwhere(np.asarray(s.terrain) != E.WATER)[0]
    pos = jnp.tile(jnp.asarray(land, dtype=jnp.int32), (3, 1))
    plants = s.plants.at[land[0], land[1]].set(2.0)
    s = s._replace(pos=pos, plants=plants)
    s2, _, _, info = E.step(s, jnp.full((3,), E.GRASP), cfg)
    out = np.asarray(info.outcome)
    assert (out == E.OUT_GATHER).sum() == 1
    assert (out == E.OUT_GATHER_LOST).sum() == 2
    # Food is conserved between the cell and inventories (before regrowth)
    regrow = float(s2.plants[land[0], land[1]]) - (2.0 - float(info.gathered.sum()))
    assert 0.0 <= regrow <= cfg.plant_regrow_forest + 1e-6
    assert np.isclose(float(s2.plant_inv.sum()), float(info.gathered.sum()))


def test_starvation_kills_with_cause():
    cfg = EnvConfig(grid_size=12, n_agents=1, max_steps=5000, season_temp=(18.0,) * 4,
                    day_temp_swing=0.0, climate_volatility=0.0, predators_per_1000=0.0)
    s = E.reset(jax.random.PRNGKey(2), cfg)
    s = s._replace(predators=s.predators._replace(alive=jnp.zeros_like(s.predators.alive)))
    s = s._replace(satiety=jnp.zeros(1), hydration=jnp.ones(1), energy=jnp.ones(1))
    step = jax.jit(lambda st, a: E.step(st, a, cfg))
    died, cause = False, None
    for _ in range(400):
        s = s._replace(hydration=jnp.ones(1), energy=jnp.ones(1))
        s, _, done, info = step(s, jnp.array([E.REST]))
        if bool(info.died[0]):
            died, cause = True, int(info.death_cause[0])
            break
    assert died and cause == E.CAUSE_STARVATION


def test_observation_shape_and_bounds():
    s = E.reset(jax.random.PRNGKey(0), CFG)
    o = E.observe(s, CFG)
    assert o.shape == (CFG.n_agents, E.obs_dim(CFG))
    assert np.all(np.isfinite(np.asarray(o)))


def test_rewind_reproduces_exact_state():
    cfg = EnvConfig(grid_size=16, n_agents=3, max_steps=250)
    rec = record_episode(random_policy, None, seed=11, cfg=cfg, snapshot_every=50)
    target = 137
    replayed = rewind(rec, target)
    # Independent straight-line replay from t=0
    straight = rewind(type(rec)(cfg=cfg, seed=11, snapshot_every=10**9,
                                snapshots={0: rec.snapshots[0]}, actions=rec.actions), target)
    for a, b in zip(jax.tree_util.tree_leaves(replayed), jax.tree_util.tree_leaves(straight)):
        np.testing.assert_array_equal(np.asarray(a), np.asarray(b))
    assert int(replayed.t) == target


def test_genotype_recombination_in_bounds():
    k = jax.random.PRNGKey(0)
    m, f = gt.sample(k, 100), gt.sample(jax.random.PRNGKey(1), 100)
    c = gt.recombine_and_mutate(jax.random.PRNGKey(2), m, f, mutation_scale=0.5)
    assert np.all((np.asarray(c.patience) >= 0.95) & (np.asarray(c.patience) <= 0.999))
    assert np.all((np.asarray(c.strength) >= 0.25) & (np.asarray(c.strength) <= 4.0))


# ------------------------------------------------------------ new mechanics
def _quiet_world(n=2, **kw):
    """Small deterministic world with animals removed, constant mild climate."""
    cfg = EnvConfig(grid_size=12, n_agents=n, max_steps=1000, climate_volatility=0.0,
                    season_temp=(18.0,) * 4, day_temp_swing=0.0, **kw)
    s = E.reset(jax.random.PRNGKey(5), cfg)
    dead = lambda an: an._replace(alive=jnp.zeros_like(an.alive))
    s = s._replace(small=dead(s.small), large=dead(s.large), predators=dead(s.predators))
    land = np.argwhere(np.asarray(s.terrain) != E.WATER)
    return cfg, s, land


def _place_animal(an, i, cell, hp):
    return an._replace(pos=an.pos.at[i].set(jnp.asarray(cell, jnp.int32)),
                       alive=an.alive.at[i].set(True), hp=an.hp.at[i].set(hp),
                       rest=an.rest.at[i].set(0))


def _neighbor_pair(terrain):
    """A land cell with a land neighbor to its east and one to its west."""
    t = np.asarray(terrain)
    for r in range(t.shape[0]):
        for c in range(1, t.shape[1] - 1):
            if t[r, c] != E.WATER and t[r, c - 1] != E.WATER and t[r, c + 1] != E.WATER:
                return (r, c - 1), (r, c), (r, c + 1)
    raise AssertionError("no land triple")


def test_large_prey_needs_a_group():
    cfg, s, _ = _quiet_world(n=2)
    west, mid, east = _neighbor_pair(s.terrain)
    s = s._replace(genotype=s.genotype._replace(strength=jnp.ones(2)),
                   pos=jnp.asarray([west, east], jnp.int32))
    s = s._replace(large=_place_animal(s.large, 0, mid, cfg.large_prey_hp))
    strike_e, strike_w = E.STRIKE_N + 2, E.STRIKE_N + 6
    # One hunter: damage 0.6 is below armor 0.8, so no effect
    s1, *_ = E.step(s, jnp.array([strike_e, E.REST]), cfg)
    assert float(s1.large.hp[0]) >= cfg.large_prey_hp - 1e-6
    # Two hunters in the same tick: 1.2 - 0.8 = 0.4 damage
    s2, *_ = E.step(s, jnp.array([strike_e, strike_w]), cfg)
    assert float(s2.large.hp[0]) < cfg.large_prey_hp - 0.3


def test_small_prey_kill_drops_meat_and_credits_hunter():
    cfg, s, _ = _quiet_world(n=1)
    west, mid, _ = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west], jnp.int32),
                   genotype=s.genotype._replace(strength=jnp.ones(1)))
    s = s._replace(small=_place_animal(s.small, 0, mid, cfg.small_prey_hp))
    s2, _, _, info = E.step(s, jnp.array([E.STRIKE_N + 2]), cfg)
    assert bool(info.kills[0, 0]) and not bool(s2.small.alive[0])
    assert float(s2.meat[mid]) > 0.9 * cfg.small_prey_meat


def test_predator_attacks_lone_agent_but_not_group():
    cfg, s, _ = _quiet_world(n=2, predator_attack_prob=1.0)
    west, mid, east = _neighbor_pair(s.terrain)
    pred = _place_animal(s.predators, 0, west, cfg.predator_hp)
    # Lone agent at mid; the other agent far away
    far = tuple(np.argwhere(np.asarray(s.terrain) != E.WATER)[-1])
    lone = s._replace(pos=jnp.asarray([mid, far], jnp.int32), predators=pred)
    _, _, _, info = E.step(lone, jnp.array([E.REST, E.REST]), cfg)
    assert bool(info.attacked_by_predator[0])
    # Two agents side by side: the predator is deterred
    grouped = s._replace(pos=jnp.asarray([mid, east], jnp.int32), predators=pred)
    _, _, _, info = E.step(grouped, jnp.array([E.REST, E.REST]), cfg)
    assert not bool(info.attacked_by_predator.any())


def test_strike_on_agent_is_violence():
    cfg, s, _ = _quiet_world(n=2)
    west, mid, _ = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west, mid], jnp.int32))
    s2, _, _, info = E.step(s, jnp.array([E.STRIKE_N + 2, E.REST]), cfg)
    assert bool(info.struck_by_agent[1]) and float(s2.health[1]) < 1.0
    assert int(info.outcome[0]) == E.OUT_STRIKE_AGENT


def test_disease_runs_its_course_then_immunity():
    cfg, s, _ = _quiet_world(n=1, disease_duration=20)
    s = s._replace(infection=jnp.array([20], jnp.int32))
    step = jax.jit(lambda st, a: E.step(st, a, cfg))
    recovered = False
    for _ in range(25):
        s, _, _, info = step(s, jnp.array([E.REST]))
        recovered |= bool(info.recovered[0])
    assert recovered and float(s.immunity[0]) > 0.9 and int(s.infection[0]) == 0


def test_contact_transmission():
    cfg, s, _ = _quiet_world(n=2, contact_infection=1.0)
    west, mid, _ = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west, mid], jnp.int32),
                   infection=jnp.array([100, 0], jnp.int32))
    _, _, _, info = E.step(s, jnp.array([E.REST, E.REST]), cfg)
    assert bool(info.newly_infected[1])


def test_winter_cold_kills_in_the_open():
    cfg = EnvConfig(grid_size=12, n_agents=1, max_steps=5000, climate_volatility=0.0,
                    season_temp=(-15.0,) * 4, forest_fraction=0.0)
    s = E.reset(jax.random.PRNGKey(3), cfg)
    s = s._replace(predators=s.predators._replace(alive=jnp.zeros_like(s.predators.alive)))
    step = jax.jit(lambda st, a: E.step(st, a, cfg))
    cause = None
    for _ in range(2000):
        s = s._replace(satiety=jnp.ones(1), hydration=jnp.ones(1), energy=jnp.ones(1))
        s, _, _, info = step(s, jnp.array([E.REST]))
        if bool(info.died[0]):
            cause = int(info.death_cause[0])
            break
    assert cause == E.CAUSE_COLD


def test_weather_spells_have_bounded_duration():
    cfg = EnvConfig(grid_size=12, n_agents=1, max_steps=3000, climate_volatility=0.5)
    s = E.reset(jax.random.PRNGKey(9), cfg)
    step = jax.jit(lambda st, a: E.step(st, a, cfg))
    changes, seen = 0, set()
    for _ in range(1500):
        s = s._replace(health=jnp.ones(1), alive=jnp.ones(1, bool))
        s, _, _, info = step(s, jnp.array([E.REST]))
        changes += int(bool(info.weather_changed))
        seen.add(int(info.weather))
        assert 0 <= int(s.weather_timer) <= cfg.spell_max
    assert changes >= 3 and len(seen) >= 3


def test_trauma_raises_pain_aversion_phenotype():
    cfg, s, _ = _quiet_world(n=2)
    west, mid, _ = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west, mid], jnp.int32),
                   genotype=s.genotype._replace(temperament_drift=jnp.ones(2)))
    before = float(s.pain_aversion[1])
    s2, *_ = E.step(s, jnp.array([E.STRIKE_N + 2, E.REST]), cfg)
    assert float(s2.pain_aversion[1]) > before
    assert float(s2.stress[1]) > 0.0


def test_huddling_keeps_agents_warmer():
    cfg = EnvConfig(grid_size=12, n_agents=2, max_steps=1000, climate_volatility=0.0,
                    season_temp=(0.0,) * 4, day_temp_swing=0.0, forest_fraction=0.0)
    s = E.reset(jax.random.PRNGKey(4), cfg)
    west, mid, _ = _neighbor_pair(s.terrain)
    far = tuple(np.argwhere(np.asarray(s.terrain) != E.WATER)[-1])
    g = s.genotype._replace(insulation=jnp.ones(2))
    step = jax.jit(lambda st, a: E.step(st, a, cfg))
    temps = {}
    for name, pos in [("together", [west, mid]), ("apart", [west, far])]:
        st = s._replace(pos=jnp.asarray(pos, jnp.int32), genotype=g)
        for _ in range(100):
            st, *_ = step(st, jnp.array([E.REST, E.REST]))
        temps[name] = float(st.body_temp[0])
    assert temps["together"] > temps["apart"] + 0.03


# ------------------------------------------------------------ Phase 2 social
def test_actions_beyond_strikes_are_not_strikes():
    cfg, s, _ = _quiet_world(n=2)
    west, mid, _ = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west, mid], jnp.int32))
    for a in [E.RELEASE, E.TOUCH_N + 2, E.TOKEN_0, E.TOKEN_0 + 3]:
        s2, _, _, info = E.step(s, jnp.array([a, E.REST]), cfg)
        assert not bool(info.struck_by_agent.any()), E.ACTION_NAMES[a]


def test_release_drops_food_and_is_seen_as_gift():
    cfg, s, _ = _quiet_world(n=2)
    west, mid, _ = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west, mid], jnp.int32), meat_inv=jnp.array([2.0, 0.0]),
                   meat=jnp.zeros_like(s.meat))
    s2, _, _, info = E.step(s, jnp.array([E.RELEASE, E.REST]), cfg)
    assert np.isclose(float(s2.meat_inv[0]), 1.0 * (1 - cfg.meat_spoil_inventory))
    assert float(s2.meat[west]) > 0.9
    assert bool(info.gifts[0, 1])
    assert float(s2.memory[1, 0, E.MEM_GAVE_NEAR_ME]) > 0.9


def test_touch_memory_and_social_reward():
    cfg, s, _ = _quiet_world(n=2)
    west, mid, _ = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west, mid], jnp.int32))
    _, r_rest, _, _ = E.step(s, jnp.array([E.REST, E.REST]), cfg)
    s2, r, _, info = E.step(s, jnp.array([E.TOUCH_N + 2, E.REST]), cfg)
    assert bool(info.touches[0, 1])
    assert float(s2.memory[1, 0, E.MEM_TOUCHED_ME]) > 0.9
    assert float(r[0]) > float(r_rest[0]) and float(r[1]) > float(r_rest[1])


def test_violence_is_remembered_by_victim_and_witnesses():
    cfg, s, _ = _quiet_world(n=3)
    west, mid, east = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west, mid, east], jnp.int32))
    s2, _, _, info = E.step(s, jnp.array([E.STRIKE_N + 2, E.REST, E.REST]), cfg)
    assert bool(info.hits[0, 1]) and not bool(info.hits[0, 2])
    assert float(s2.memory[1, 0, E.MEM_STRUCK_ME]) > 0.9
    assert float(s2.memory[2, 0, E.MEM_SEEN_VIOLENT]) > 0.9   # third party saw it
    assert float(s2.memory[0, 0, E.MEM_SEEN_VIOLENT]) == 0.0  # striker does not witness itself
    assert float(s2.memory[2, 0, E.MEM_STRUCK_ME]) == 0.0


def test_tokens_appear_in_listener_view_next_tick():
    cfg, s, _ = _quiet_world(n=2)
    west, mid, _ = _neighbor_pair(s.terrain)
    s = s._replace(pos=jnp.asarray([west, mid], jnp.int32))
    s2, *_ = E.step(s, jnp.array([E.TOKEN_0 + 2, E.REST]), cfg)
    obs = np.asarray(E.observe(s2, cfg))
    v, r, c = cfg.view_size, cfg.view_radius, E.N_OBS_CHANNELS
    win = obs[1, :v * v * c].reshape(v, v, c)
    tok_start = c - E.N_TOKENS
    speaker = win[r, r - 1]                                   # agent 0 is west of agent 1
    assert speaker[tok_start + 2] == 1.0 and speaker[tok_start:].sum() == 1.0
    app_start = c - E.N_TOKENS - E.N_APPEARANCE
    np.testing.assert_allclose(speaker[app_start:app_start + 3], np.asarray(s2.appearance[0]), rtol=1e-6)


def test_fixed_population_across_worlds():
    cfg = EnvConfig(grid_size=16, n_agents=3)
    g = gt.sample(jax.random.PRNGKey(1), 3)
    app = jnp.ones((3, E.N_APPEARANCE)) * 0.5
    s1 = E.reset(jax.random.PRNGKey(2), cfg, genotype=g, appearance=app)
    s2 = E.reset(jax.random.PRNGKey(3), cfg, genotype=g, appearance=app)
    np.testing.assert_array_equal(np.asarray(s1.genotype.strength), np.asarray(s2.genotype.strength))
    assert not np.array_equal(np.asarray(s1.terrain), np.asarray(s2.terrain))
